class BalanceException(Exception):
    pass

class BankAccount:
    def __init__(self, initiaAmount, accname):
        self.balance = initiaAmount
        self.name = accname
        print(f"\nAccount {self.name} created \nbalance ${self.balance:.2f}")

    def getBalance(self):
        print(f"\nAccount {self.name} balance is ${self.balance:.2f}")
    
    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"\n Deposited: ${amount:.2f}")
            print(f"New balance: ${self.balance:.2f}")

        else:
            print("Deposit amount must be positive.")

    def transction(self, amount):
        if amount > 0:
            if amount <= self.balance:
                return
            else:
                raise BalanceException(f"\nsorry,account {self.name} only has a balance of ${self.balance:.2f}")
        else:
            print("Withdrawal amount must be positive.")

    def withdraw(self, amount):
        try:
            self.transction(amount)
            self.balance -= amount
            print(f"\n {self.name} Withdrawn complte")
            print(f"New balance: ${self.balance:.2f}")
        except BalanceException as e:
            print(f'\nwithdrawal interrupted: {e}')
    
    def transfer(self, amount, other_account):
        try:
            print('\n**********\n\nBeginning Transfer..')
            self.transction(amount)
            self.withdraw(amount)
            self.deposit(amount)    
            print(f'\nTransfer Complte ! \n\n**********')
        except BalanceException as e:
            print(f'\nTransfer interrupted: {e}')

class intrestRewordAccount(BankAccount):
    def deposit(self, amount):
        self.balance += amount
        interest = amount * 0.05
        self.balance += interest
        print(f"\n Deposited: ${amount:.2f} with interest ${interest:.2f}")
        self.getBalance()

class savingsAccount(intrestRewordAccount):
    def __init__(self, initiaAmount, accname, ):
        super().__init__(initiaAmount, accname)
        self.fee = 5

    def withdraw(self, amount):
        try:
            self.transction(amount + self.fee)
            self.balance -= (amount + self.fee)
            print(f"\n {self.name} Withdrawn complte with fee ${self.fee:.2f}")
            self.getBalance()
        except BalanceException as e:
            print(f'\nwithdrawal interrupted: {e}')