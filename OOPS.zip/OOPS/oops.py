from bank_account import *

dhruv=BankAccount(1000,"Dhruv")

preet=BankAccount(2000,"Preet")

dhruv.getBalance()
preet.getBalance()

dhruv.deposit(500)
preet.deposit(1000)

dhruv.withdraw(2000)
preet.withdraw(2500)

dhruv.transfer(300,preet)
preet.transfer(5000,dhruv)

mihir=intrestRewordAccount(5000,"Mihir")
mihir.getBalance()

mihir.deposit(100)

mihir.transfer(1000,dhruv)

rutvik=savingsAccount(2000,"Rutvik")
rutvik.getBalance()

rutvik.deposit(500)

rutvik.transfer(10000,preet)
rutvik.transfer(1000,preet)