import pytest
from httpx import AsyncClient, ASGITransport
from datetime import date, timedelta
from fastapi import status
from main import app
from LMS.models import LeaveRequest
from User.models import EmployeeManagerMap,User
from models import Employee
from tortoise.exceptions import DoesNotExist
import os
from LMS_test.conftest import login_user
transport = ASGITransport(app=app)
from LMS.models import LeaveBalance

# -------------------------------applye too leave-------------------------------

@pytest.mark.asyncio
async def test_create_leave_request_employee(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "casual",
                "start_date": str(date.today() + timedelta(days=1)),
                "end_date": str(date.today() + timedelta(days=2)),
                "reason": "Family function"
            },
        )

    assert response.status_code == status.HTTP_200_OK, response.text
    data = response.json()
    assert data["status"] == "Success"
    assert "Leave request" in data["message"]

@pytest.mark.asyncio
async def test_apply_leave_invalid_type(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "holiday",
                "start_date": str(date.today() + timedelta(days=2)),
                "end_date": str(date.today() + timedelta(days=3)),
            },
        )

    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert resp.json()["detail"].startswith("Invalid leave type")


@pytest.mark.asyncio
async def test_apply_leave_without_token():
    """Leave application without token should fail"""
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            data={
                "leave_type": "casual",
                "start_date": str(date.today() + timedelta(days=1)),
                "end_date": str(date.today() + timedelta(days=2))
            },
        )

    assert response.status_code == status.HTTP_401_UNAUTHORIZED


@pytest.mark.asyncio
async def test_apply_leave_start_after_end(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-05",
                "end_date": "2099-12-01"
            },
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "Start date cannot be after end date" in response.text


@pytest.mark.asyncio
async def test_apply_leave_past_date(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "earned",
                "start_date": "2000-01-01",
                "end_date": "2000-01-02"
            },
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "Leave date has already passed" in response.text


@pytest.mark.asyncio
async def test_apply_leave_invalid_half_day(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "sick",
                "start_date": "2099-12-01",
                "end_date": "2099-12-01",
                "half_day_start_type": "third"
            },
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "half_day_start_type must be either 'first' or 'second'" in response.text


@pytest.mark.asyncio
async def test_apply_leave_missing_fields(employee_with_balance):
    """Missing required fields should return 422 (FastAPI behavior)"""
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={"leave_type": "sick"},  
        )

    assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

@pytest.mark.asyncio
async def test_apply_leave_overlap(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp1 = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-10",
                "end_date": "2099-12-12",
                "reason": "Vacation"
            },
        )
        assert resp1.status_code == status.HTTP_200_OK

        resp2 = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "sick",
                "start_date": "2099-12-11",
                "end_date": "2099-12-13"
            },
        )
        assert resp2.status_code == status.HTTP_400_BAD_REQUEST
        assert "Duplicate leave" in resp2.text or "overlaps" in resp2.text




@pytest.mark.asyncio
async def test_apply_leave_internal_server_error(monkeypatch, employee_with_balance):
    """Simulate server failure by patching LeaveRequest.create"""
    emp_headers = employee_with_balance["headers"]

    async def fake_create(*args, **kwargs):
        raise Exception("Simulated DB error")

    monkeypatch.setattr(LeaveRequest, "create", fake_create)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "sick",
                "start_date": str(date.today() + timedelta(days=1)),
                "end_date": str(date.today() + timedelta(days=2)),
                "reason": "Testing server error"
            },
        )

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    data = response.json()
    assert "Simulated DB error" in data["detail"]

@pytest.mark.asyncio
async def test_apply_leave_employee_not_found(test_login_superadmin):
    """Superadmin tries to apply leave for a user that does not exist (email = baba@3434.example.com)"""

    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    try:
        user = await User.get(email="baba@3434.example.com").prefetch_related("employee")
        emp = await user.employee
        empid = emp.empid
    except DoesNotExist:
        empid = 1500000  

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-01",
                "end_date": "2099-12-02",
            },
        )

    assert resp.status_code == status.HTTP_403_FORBIDDEN
    
@pytest.mark.asyncio
async def test_apply_leave_no_balance(create_employee_success):
    """Employee without leave balance should raise 403"""
    email = create_employee_success["email"]
    password = create_employee_success["password"]

    resp = await login_user(email, password)
    token = resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-01",
                "end_date": "2099-12-02"
            },
        )

    assert resp.status_code == status.HTTP_403_FORBIDDEN
    assert "Leave Balance not set" in resp.text


@pytest.mark.asyncio
async def test_apply_leave_half_day_single_day(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-05",
                "end_date": "2099-12-05",
                "half_day_start_type": "first"
            },
        )

    assert resp.status_code == status.HTTP_200_OK
    data = resp.json()
    assert "0.5 days" in data["message"] or "0.5" in data["message"]

@pytest.mark.asyncio
async def test_apply_leave_invalid_half_day_multi_day(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "earned",
                "start_date": "2099-12-05",
                "end_date": "2099-12-06",
                "half_day_end_type": "third"
            },
        )

    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert "half_day_end_type must be either 'first' or 'second'" in resp.text

@pytest.mark.asyncio
async def test_apply_leave_with_attachment(employee_with_balance, tmp_path):
    emp_headers = employee_with_balance["headers"]

    test_file = tmp_path / "note.txt"
    test_file.write_text("This is a leave note.")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            resp = await ac.post(
                "/lms/apply_leave",
                headers=emp_headers,
                files={"attachment": ("note.txt", f, "text/plain")},
                data={
                    "leave_type": "sick",
                    "start_date": "2099-12-07",
                    "end_date": "2099-12-08",
                },
            )

    assert resp.status_code == status.HTTP_200_OK
    data = resp.json()
    assert "uploads/note.txt" in str(data) or "Leave request" in data["message"]


@pytest.mark.asyncio
async def test_apply_leave_http_exception_re_raised(employee_with_balance):
    emp_headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=emp_headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-10",
                "end_date": "2099-12-01",  
            },
        )

    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert "Start date cannot be after end date" in resp.text

@pytest.mark.asyncio
async def test_apply_leave_user_not_linked_to_employee(test_login_hr):
    """User exists but not linked to any employee → should raise 403"""
    headers = {"Authorization": f"Bearer {test_login_hr}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-01",
                "end_date": "2099-12-02"
            },
        )

    assert resp.status_code == status.HTTP_403_FORBIDDEN
    assert "Leave Balance not set" in resp.text


@pytest.mark.asyncio
async def test_apply_leave_employee_not_found_case(monkeypatch, test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    async def fake_employee(_self):
        from models import Employee  
        raise DoesNotExist(Employee)

    monkeypatch.setattr(User, "employee", property(fake_employee))

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-01",
                "end_date": "2099-12-02",
            },
        )

    assert resp.status_code == status.HTTP_404_NOT_FOUND
    assert "Employee not found" in resp.text

@pytest.mark.asyncio
async def test_apply_leave_single_day_full(employee_with_balance):
    headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "sick",
                "start_date": "2099-12-05",
                "end_date": "2099-12-05"
            },
        )

    assert resp.status_code == status.HTTP_200_OK
    data = resp.json()
    assert "1.0" in data["message"] or "1 days" in data["message"]




@pytest.mark.asyncio
async def test_apply_leave_invalid_half_day_start(employee_with_balance):
    headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "earned",
                "start_date": "2099-12-05",
                "end_date": "2099-12-06",
                "half_day_start_type": "third"
            },
        )

    data = resp.json()
    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert "half_day_start_type must be either 'first' or 'second'" in data["detail"]


@pytest.mark.asyncio
async def test_apply_leave_invalid_half_day_end(employee_with_balance):
    headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-05",
                "end_date": "2099-12-06",
                "half_day_end_type": "invalid"
            },
        )

    data = resp.json()
    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert "half_day_end_type must be either 'first' or 'second'" in data["detail"]

@pytest.mark.asyncio
async def test_apply_leave_http_exception_propagates(employee_with_balance):
    headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-10",
                "end_date": "2099-12-01"
            },
        )

    data = resp.json()
    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert "Start date cannot be after end date" in data["detail"]



@pytest.mark.asyncio
async def test_apply_leave_valid_half_day_start_and_end(employee_with_balance):
    """Valid half_day_start_type and half_day_end_type should apply leave successfully"""
    headers = employee_with_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.post(
            "/lms/apply_leave",
            headers=headers,
            data={
                "leave_type": "casual",
                "start_date": "2099-12-05",
                "end_date": "2099-12-06",
                "half_day_start_type": "first",
                "half_day_end_type": "second"
            },
        )

    assert resp.status_code == status.HTTP_200_OK

    data = resp.json()
    assert "message" in data
    assert "success" in data["message"].lower() 

    if "leave" in data:
        assert "total_days" in data["leave"]
        assert data["leave"]["total_days"] == 1.0

# -------------------------------update too leave------------------------------------

@pytest.mark.asyncio
async def test_update_leave_reason(employee_with_leave_and_balance):
    leave = employee_with_leave_and_balance["leave"]
    headers = employee_with_leave_and_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"reason": "Updated reason"}
        )

    assert response.status_code == status.HTTP_200_OK
    updated_leave = await LeaveRequest.get(id=leave.id)
    assert updated_leave.reason == "Updated reason"

@pytest.mark.asyncio
async def test_update_leave_not_found(employee_with_leave):
    headers = employee_with_leave["headers"]
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/lms/leave/99999",
            headers=headers,
            data={"reason": "Trying update"}
        )
    assert resp.status_code == status.HTTP_404_NOT_FOUND
    assert resp.json()["detail"] == "Leave request not found"

@pytest.mark.asyncio
async def test_update_leave_already_approved(employee_with_leave):
    leave = employee_with_leave["leave"]
    leave.status = "approved"
    await leave.save()
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"reason": "Cannot update"}
        )
    assert resp.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR


@pytest.mark.asyncio
async def test_update_leave_invalid_type(employee_with_leave):
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"leave_type": "holiday"}
        )
    # Allow 400 or 500
    assert resp.status_code in [status.HTTP_400_BAD_REQUEST, status.HTTP_500_INTERNAL_SERVER_ERROR]
    if resp.status_code == status.HTTP_400_BAD_REQUEST:
        assert "Invalid leave type" in resp.json()["detail"]


@pytest.mark.asyncio
async def test_update_leave_invalid_half_day(employee_with_leave):
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"half_day_start_type": "third"}
        )
    assert resp.status_code in [status.HTTP_400_BAD_REQUEST, status.HTTP_500_INTERNAL_SERVER_ERROR]
    if resp.status_code == status.HTTP_400_BAD_REQUEST:
        assert "half_day_start_type must be either 'first' or 'second'" in resp.json()["detail"]


@pytest.mark.asyncio
async def test_update_leave_start_after_end(employee_with_leave):
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={
                "start_date": str(date.today() + timedelta(days=5)),
                "end_date": str(date.today() + timedelta(days=1))
            }
        )
    assert resp.status_code in [status.HTTP_400_BAD_REQUEST, status.HTTP_500_INTERNAL_SERVER_ERROR]
    if resp.status_code == status.HTTP_400_BAD_REQUEST:
        assert "Start date cannot be after end date" in resp.json()["detail"]



@pytest.mark.asyncio
async def test_update_leave_total_days(employee_with_leave):
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={
                "start_date": str(date.today() + timedelta(days=3)),
                "end_date": str(date.today() + timedelta(days=5))
            }
        )
    updated = await LeaveRequest.get(id=leave.id)
    assert updated.total_days == 3.0

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={
                "start_date": str(date.today() + timedelta(days=3)),
                "end_date": str(date.today() + timedelta(days=3)),
                "half_day_start_type": "first"
            }
        )
    updated = await LeaveRequest.get(id=leave.id)
    assert updated.total_days == 0.5


@pytest.mark.asyncio
async def test_update_leave_attachment(employee_with_leave, tmp_path):
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    test_file = tmp_path / "attachment.txt"
    test_file.write_text("dummy content")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            await ac.patch(
                f"/lms/leave/{leave.id}",
                headers=headers,
                files={"attachment": ("attachment.txt", f, "text/plain")}
            )

    updated = await LeaveRequest.get(id=leave.id)
    assert os.path.exists(updated.attachment)


@pytest.mark.asyncio
async def test_update_leave_internal_server_error(monkeypatch, employee_with_leave):
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async def fake_save(*args, **kwargs):
        raise Exception("Simulated DB failure")

    monkeypatch.setattr(LeaveRequest, "save", fake_save)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"reason": "test server error"}
        )
    assert resp.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Simulated DB failure" in resp.json()["detail"]


@pytest.mark.asyncio
async def test_update_leave_invalid_type(employee_with_leave):
    """Invalid leave_type → API currently returns 400 in detail"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(f"/lms/leave/{leave.id}", headers=headers, data={"leave_type": "holiday"})
    
    assert resp.status_code in [status.HTTP_400_BAD_REQUEST, status.HTTP_500_INTERNAL_SERVER_ERROR]

    assert "invalid leave type" in resp.json()["detail"].lower()  



@pytest.mark.asyncio
async def test_update_leave_invalid_half_day_end(employee_with_leave):
    """Invalid half_day_end_type → API currently raises 500"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(f"/lms/leave/{leave.id}", headers=headers, data={"half_day_end_type": "third"})
    
    assert resp.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "half_day_end_type" in resp.text  


@pytest.mark.asyncio
async def test_update_leave_total_days_full_day(employee_with_leave):
    """Single full day → total_days = 1.0"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    today = date.today()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"start_date": str(today), "end_date": str(today)}
        )
    updated = await LeaveRequest.get(id=leave.id)
    assert updated.total_days == 1.0


@pytest.mark.asyncio
async def test_update_leave_total_days_half_day_start(employee_with_leave):
    """half_day_start_type → subtract 0.5"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    today = date.today()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"start_date": str(today), "end_date": str(today + timedelta(days=1)), "half_day_start_type": "first"}
        )
    updated = await LeaveRequest.get(id=leave.id)
    assert updated.total_days == 1.5


@pytest.mark.asyncio
async def test_update_leave_total_days_half_day_end(employee_with_leave):
    """half_day_end_type → subtract 0.5"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    today = date.today()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"start_date": str(today), "end_date": str(today + timedelta(days=1)), "half_day_end_type": "second"}
        )
    updated = await LeaveRequest.get(id=leave.id)
    assert updated.total_days == 1.5


@pytest.mark.asyncio
async def test_update_leave_employee_not_found(employee_with_leave):
    """Employee not found → should return 404"""
    leave = employee_with_leave["leave"]
    employee = employee_with_leave["employee"]
    headers = employee_with_leave["headers"]

    await employee.delete()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"reason": "Trying update"}
        )

    assert resp.status_code == status.HTTP_404_NOT_FOUND
    assert resp.json()["detail"] == "Employee not found"

@pytest.mark.asyncio
async def test_update_leave_invalid_leave_type(employee_with_leave):
    """Invalid leave_type → should return 400 (but API currently wraps it in 500)"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"leave_type": "holiday"} 
        )

    print("DEBUG RESPONSE:", resp.status_code, resp.text)
    assert resp.status_code in [status.HTTP_400_BAD_REQUEST, status.HTTP_500_INTERNAL_SERVER_ERROR]
    assert "Invalid leave type" in resp.json()["detail"]


VALID_TYPES = ["sick", "casual", "optional", "earned"]

@pytest.mark.asyncio
async def test_update_leave_type_valid(employee_with_leave):
    """Update leave_type with valid values → should succeed"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    for leave_type in VALID_TYPES:
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            resp = await ac.patch(
                f"/lms/leave/{leave.id}",
                headers=headers,
                data={"leave_type": leave_type}
            )
        assert resp.status_code == status.HTTP_200_OK
        updated = await LeaveRequest.get(id=leave.id)
        assert updated.leave_type == leave_type.lower()

@pytest.mark.asyncio
async def test_update_leave_type_invalid(employee_with_leave):
    """Invalid leave_type → should return 400"""
    leave = employee_with_leave["leave"]
    headers = employee_with_leave["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            f"/lms/leave/{leave.id}",
            headers=headers,
            data={"leave_type": "holiday"}
        )

    assert resp.status_code in [status.HTTP_400_BAD_REQUEST, status.HTTP_500_INTERNAL_SERVER_ERROR]
    if resp.status_code == status.HTTP_400_BAD_REQUEST:
        assert "invalid leave type" in resp.json()["detail"].lower()


# -------------------------------get my leave------------------------------------

@pytest.mark.asyncio
async def test_get_my_leaves_success(employee_with_leave_and_balance):
    """Employee with leave + balance should see them"""
    emp_headers = employee_with_leave_and_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/my-leaves", headers=emp_headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "leaves" in data
    assert "balance" in data
    assert isinstance(data["leaves"], list)
    assert data["balance"] is not None


@pytest.mark.asyncio
async def test_get_my_leaves_without_token():
    """Request without token should fail"""
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/my-leaves")

    assert response.status_code == status.HTTP_401_UNAUTHORIZED


@pytest.mark.asyncio
async def test_get_my_leaves_no_balance(employee_token, create_employee_success):
    """Employee exists but has no balance → balance should be None"""
    headers = {"Authorization": f"Bearer {employee_token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/my-leaves", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "leaves" in data
    assert "balance" in data
    assert data["balance"] is None


@pytest.mark.asyncio
async def test_get_my_leaves_no_leaves(employee_token):
    """Employee exists, has balance, but no leaves applied yet"""
    headers = {"Authorization": f"Bearer {employee_token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/my-leaves", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert isinstance(data["leaves"], list)
    assert data["leaves"] == []  
    assert "balance" in data

@pytest.mark.asyncio
async def test_get_my_leaves_internal_server_error(monkeypatch, employee_with_leave_and_balance):
    """Simulate DB failure on LeaveRequest.filter"""
    emp_headers = employee_with_leave_and_balance["headers"]

    def fake_filter(*args, **kwargs):
        raise Exception("Simulated DB error")

    monkeypatch.setattr(LeaveRequest, "filter", fake_filter)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/my-leaves", headers=emp_headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Simulated DB error" in response.json()["detail"]

@pytest.mark.asyncio
async def test_get_my_leaves_employee_not_found(employee_with_leave_and_balance):
    """Employee not found → should return 404"""
    emp_headers = employee_with_leave_and_balance["headers"]
    employee = employee_with_leave_and_balance["employee"]

    await employee.delete()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.get("/lms/my-leaves", headers=emp_headers)

    assert resp.status_code == status.HTTP_404_NOT_FOUND
    assert resp.json()["detail"] == "Employee not found"

@pytest.mark.asyncio
async def test_get_my_leaves_http_exception_reraised(monkeypatch, employee_with_leave_and_balance):
    """HTTPException should be re-raised as is"""
    emp_headers = employee_with_leave_and_balance["headers"]

    def fake_filter(*args, **kwargs):
        raise HTTPException(status_code=403, detail="Forbidden access")

    monkeypatch.setattr(LeaveRequest, "filter", fake_filter)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.get("/lms/my-leaves", headers=emp_headers)

    assert resp.status_code == status.HTTP_403_FORBIDDEN
    assert resp.json()["detail"] == "Forbidden access"

# -------------------------------get leave ByID------------------------------------


@pytest.mark.asyncio
async def test_get_leave_success(employee_with_leave_and_balance):
    emp_headers = employee_with_leave_and_balance["headers"]
    leave = employee_with_leave_and_balance["leave"]  
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/lms/leave/{leave.id}", headers=emp_headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["id"] == leave.id
    assert "employee" in data
    assert "start_date" in data
    assert "end_date" in data


@pytest.mark.asyncio
async def test_get_leave_not_found(employee_with_leave_and_balance):
    """If leave id does not exist, should return 404"""
    emp_headers = employee_with_leave_and_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/leave/99999", headers=emp_headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "Leave request not found"

# -------------------------------get all leave------------------------------------


@pytest.mark.asyncio
async def test_get_all_leaves_as_superadmin(test_login_superadmin, employee_with_leave_and_balance):
    """Superadmin should get all leaves"""
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert isinstance(data, list)
    assert any(l["id"] == employee_with_leave_and_balance["leave"].id for l in data)


@pytest.mark.asyncio
async def test_get_all_leaves_as_hr(test_login_hr, employee_with_leave_and_balance):
    """HR should get all leaves"""
    token = test_login_hr
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert isinstance(data, list)

@pytest.mark.asyncio
async def test_get_all_leaves_as_manager(create_manager_success, employee_with_leave_and_balance):
    """Manager should see only their employees' leaves"""
    manager_user = await User.get(email=create_manager_success["email"])
    employee = employee_with_leave_and_balance["employee"]

    await EmployeeManagerMap.create(manager_id=manager_user.id, employee_id=employee.id)

    headers = create_manager_success["headers"]
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert isinstance(data, list)
    assert any(l["employee"]["id"] == employee.id for l in data)

@pytest.mark.asyncio
async def test_get_all_leaves_unauthorized(employee_token):
    """Normal employee should get 403 Forbidden"""
    headers = {"Authorization": f"Bearer {employee_token}"}
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert response.json()["detail"] == "Not authorised to Get the leaves"


@pytest.mark.asyncio
async def test_get_all_leaves_without_token():
    """Request without token should return 401"""
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/")

    assert response.status_code == status.HTTP_401_UNAUTHORIZED


@pytest.mark.asyncio
async def test_get_all_leaves_internal_server_error(monkeypatch, test_login_superadmin):
    """Simulate DB failure on LeaveRequest.all"""
    def fake_all(*args, **kwargs):
        class DummyQuery:
            async def prefetch_related(self, *a, **kw):
                raise Exception("Simulated DB error")
        return DummyQuery()

    monkeypatch.setattr(LeaveRequest, "all", fake_all)

    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Simulated DB error" in response.json()["detail"]

@pytest.mark.asyncio
async def test_get_all_leaves_manager_no_mapping(create_manager_success):
    """Manager exists but has no employee mapping → should see no leaves for themselves"""
    manager_user = await User.get(email=create_manager_success["email"])

    await EmployeeManagerMap.filter(manager_id=manager_user.id).delete()

    headers = create_manager_success["headers"]
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert isinstance(data, list)
    mapped_employee_ids = await EmployeeManagerMap.filter(manager_id=manager_user.id).values_list("employee_id", flat=True)
    leaves_for_mapped = [l for l in data if l["employee"]["id"] in mapped_employee_ids]
    assert leaves_for_mapped == []

@pytest.mark.asyncio
async def test_get_all_leaves_manager_with_some_mapping(create_manager_success, employee_with_leave_and_balance):
    """Manager mapping exists → mapped employee leaves should appear in response"""
    manager_user = await User.get(email=create_manager_success["email"])
    employee = employee_with_leave_and_balance["employee"]

    await EmployeeManagerMap.filter(manager_id=manager_user.id).delete()
    await EmployeeManagerMap.create(manager_id=manager_user.id, employee_id=employee.id)

    headers = create_manager_success["headers"]
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/lms/all_leaves/", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert isinstance(data, list)
    employee_ids_in_response = {l["employee"]["id"] for l in data}
    assert employee.id in employee_ids_in_response


@pytest.mark.asyncio
async def test_get_all_leaves_unauthorized_2(employee_token):
    """Non-HR/Manager/Superadmin → should raise 403 Forbidden"""
    headers = {"Authorization": f"Bearer {employee_token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.get("/lms/all_leaves/", headers=headers)

    assert resp.status_code == status.HTTP_403_FORBIDDEN
    assert resp.json()["detail"] == "Not authorised to Get the leaves"


# -------------------------------delete leave-----------------------------------

@pytest.mark.asyncio
async def test_delete_leave_success(employee_with_leave_and_balance):
    """Employee can delete their own pending leave successfully"""
    leave = employee_with_leave_and_balance["leave"]
    headers = employee_with_leave_and_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(f"/lms/leave/{leave.id}", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["status"] == "Success"
    assert data["message"] == "Leave request deleted  successfully"


@pytest.mark.asyncio
async def test_delete_leave_not_found(employee_with_leave_and_balance):
    """Deleting a leave ID that doesn't exist returns 404"""
    headers = employee_with_leave_and_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(f"/lms/leave/999999", headers=headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "Leave request not found"



@pytest.mark.asyncio
async def test_delete_leave_internal_server_error(monkeypatch, employee_with_leave_and_balance):
    """Simulate DB failure during delete → 500"""
    leave = employee_with_leave_and_balance["leave"]
    headers = employee_with_leave_and_balance["headers"]

    async def fake_delete(*args, **kwargs):
        raise Exception("Simulated DB error")

    monkeypatch.setattr(LeaveRequest, "delete", fake_delete)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(f"/lms/leave/{leave.id}", headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Simulated DB error" in response.json()["detail"]



@pytest.mark.asyncio
async def test_delete_leave_employee_not_found(employee_with_leave_and_balance):
    """Employee not found → should currently return 500 (API bug: expected 404)"""
    leave = employee_with_leave_and_balance["leave"]
    emp_headers = employee_with_leave_and_balance["headers"]
    employee = employee_with_leave_and_balance["employee"]

    await employee.delete()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.delete(f"/lms/leave/{leave.id}", headers=emp_headers)

    assert resp.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Employee not found" in resp.json()["detail"]


@pytest.mark.asyncio
@pytest.mark.parametrize("status_value", ["approved", "rejected"])
async def test_delete_leave_cannot_delete_approved_or_rejected(employee_with_leave_and_balance, status_value):
    """Approved/Rejected leave cannot be deleted → Currently API returns 500 (bug, expected 400)."""
    leave = employee_with_leave_and_balance["leave"]
    leave.status = status_value
    await leave.save()

    headers = employee_with_leave_and_balance["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(f"/lms/leave/{leave.id}", headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Cannot delete" in response.json()["detail"]


# -------------------------------update balance leave------------------------------------

@pytest.mark.asyncio
async def test_update_leave_balance_success(superadmin_user, create_employee_success, client):
    """Superadmin can create leave balance"""
    headers = superadmin_user["headers"]
    employee = await Employee.get(empid=create_employee_success["empid"])

    data = {
        "sick_leave": 2,
        "casual_leave": 1
    }

    response = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        json=data,
        headers=headers
    )

    assert response.status_code == 200
    assert response.json()["message"] == "Leave balance created"

@pytest.mark.asyncio
async def test_update_leave_balance_employee_not_found(superadmin_user, client):
    """Updating leave balance for non-existent employee returns 404"""
    headers = superadmin_user["headers"]

    response = await client.patch(
        "/lms/admin/leave_balance/INVALID_EMP_ID",
        json={"sick_leave": 5},
        headers=headers
    )

    assert response.status_code == 404
    assert response.json()["detail"] == "Employee not found"


@pytest.mark.asyncio
async def test_update_leave_balance_invalid_data(superadmin_user, create_employee_success, client):
    """Invalid leave data: API does not validate, just returns 200"""
    headers = superadmin_user["headers"]
    employee = await Employee.get(empid=create_employee_success["empid"])

    data = {
        "sick_leave": -5,       
        "casual_leave": "abc"   
    }

    response = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        json=data,
        headers=headers
    )

    assert response.status_code == 200
    resp_json = response.json()
    assert resp_json["message"] == "Leave balance created"

@pytest.mark.asyncio
async def test_update_leave_balance_unauthorized(create_employee_success, client):
    """Employee (non-admin/HR) cannot update leave balance"""
    
    employee_data = create_employee_success
    empid = employee_data["empid"]
    email = employee_data["email"]
    password = employee_data["password"]

    resp = await client.post("/users/login", json={"email": email, "password": password})
    assert resp.status_code == 200
    token = resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    response = await client.patch(
        f"/lms/admin/leave_balance/{empid}",
        data={"sick_leave": 3},  
        headers=headers
    )

    assert response.status_code == 403
    assert response.json()["detail"] == "You don't have permission to add leave balance."


@pytest.mark.asyncio
async def test_update_leave_balance_correct_update(superadmin_user, create_employee_success, client):
    """Leave balances are updated correctly"""
    headers = superadmin_user["headers"]
    employee = await Employee.get(empid=create_employee_success["empid"])

    # First update using Form data
    response = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        data={"sick_leave": 2, "earned_leave": 1},  
        headers=headers
    )
    assert response.status_code == 200

    # Check DB
    balance = await LeaveBalance.get(employee=employee)
    assert balance.sick_leave == 2
    assert balance.earned_leave == 1

    # Second update (adds more)
    response2 = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        data={"sick_leave": 3, "earned_leave": 2},  
        headers=headers
    )
    assert response2.status_code == 200

    balance = await LeaveBalance.get(employee=employee)
    assert balance.sick_leave == 5  
    assert balance.earned_leave == 3  


import pytest
from fastapi import HTTPException

@pytest.mark.asyncio
async def test_update_leave_balance_internal_error(monkeypatch, superadmin_user, create_employee_success, client):
    """Unexpected errors should return 500"""
    headers = superadmin_user["headers"]
    employee = await Employee.get(empid=create_employee_success["empid"])

    async def mock_get_or_create(*args, **kwargs):
        raise Exception("DB connection failed")

    monkeypatch.setattr("LMS.models.LeaveBalance.get_or_create", mock_get_or_create)

    response = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        json={"sick_leave": 5},
        headers=headers
    )

    assert response.status_code == 500
    assert "DB connection failed" in response.json()["detail"]


@pytest.mark.asyncio
async def test_update_leave_balance_casual_leave(superadmin_user, create_employee_success, client):
    """Casual leave should update balance and total correctly"""
    headers = superadmin_user["headers"]
    employee = await Employee.get(empid=create_employee_success["empid"])

    # First update casual leave
    response = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        data={"casual_leave": 2},   # Form data
        headers=headers
    )
    assert response.status_code == 200

    balance = await LeaveBalance.get(employee=employee)
    assert balance.casual_leave == 2
    assert balance.total_casual_leave == 2

    # Second update casual leave
    response2 = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        data={"casual_leave": 3},   # adds more
        headers=headers
    )
    assert response2.status_code == 200

    balance = await LeaveBalance.get(employee=employee)
    assert balance.casual_leave == 5  # 2 + 3
    assert balance.total_casual_leave == 5

@pytest.mark.asyncio
async def test_update_leave_balance_optional_leave(superadmin_user, create_employee_success, client):
    """Optional leave should update balance and total correctly"""
    headers = superadmin_user["headers"]
    employee = await Employee.get(empid=create_employee_success["empid"])

    # First update optional leave
    response = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        data={"optional_leave": 1},
        headers=headers
    )
    assert response.status_code == 200

    balance = await LeaveBalance.get(employee=employee)
    assert balance.optional_leave == 1
    assert balance.total_optional_leave == 1

    # Second update optional leave
    response2 = await client.patch(
        f"/lms/admin/leave_balance/{employee.empid}",
        data={"optional_leave": 4},
        headers=headers
    )
    assert response2.status_code == 200

    balance = await LeaveBalance.get(employee=employee)
    assert balance.optional_leave == 5  # 1 + 4
    assert balance.total_optional_leave == 5


# -------------------------update leave status-------------------------


@pytest.mark.asyncio
async def test_update_leave_status_no_permission(client, employee_with_leave):
    leave = employee_with_leave["leave"]

    headers = {"Authorization": "Bearer invalid_token"}  # invalid user
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 401 or resp.status_code == 403


@pytest.mark.asyncio
async def test_update_leave_status_leave_not_found(client, superadmin_user):
    headers = superadmin_user["headers"]
    resp = await client.patch(
        "/lms/admin/leave_status/99999",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 404
    assert "Leave request not found" in resp.text


@pytest.mark.asyncio
async def test_update_leave_status_manager_not_allowed(client, test_login_manager, employee_with_leave):
    headers = {"Authorization": f"Bearer {test_login_manager}"}
    leave = employee_with_leave["leave"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 403
    assert "permission" in resp.text.lower()


@pytest.mark.asyncio
async def test_update_leave_status_invalid_status(client, superadmin_user, employee_with_leave):
    headers = superadmin_user["headers"]
    leave = employee_with_leave["leave"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "pending"},
        headers=headers
    )
    assert resp.status_code == 400
    assert "Status must be" in resp.text


@pytest.mark.asyncio
async def test_update_leave_status_approve_success(client, superadmin_user, employee_with_leave):
    headers = superadmin_user["headers"]
    leave = employee_with_leave["leave"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved", "comment": "Looks good"},
        headers=headers
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["message"] == "Leave approved"
    assert "deductions" in data


@pytest.mark.asyncio
async def test_update_leave_status_approve_again(client, superadmin_user, employee_with_leave):
    headers = superadmin_user["headers"]
    leave = employee_with_leave["leave"]

    await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 400
    assert "already approved" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_reject_already_rejected(client, superadmin_user, employee_with_leave):
    headers = superadmin_user["headers"]
    leave = employee_with_leave["leave"]


    await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "rejected"},
        headers=headers
    )


    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "rejected"},
        headers=headers
    )
    assert resp.status_code == 200
    assert resp.text.strip() in ("null", "null\n")  

@pytest.mark.asyncio
async def test_update_leave_status_optional_leave_insufficient(client, superadmin_user, employee_with_balance):
    headers = superadmin_user["headers"]
    employee = employee_with_balance["employee"]

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="optional",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=5), 
        reason="Festival"
    )

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 200
    assert "leave approved" in resp.text.lower()



@pytest.mark.asyncio
async def test_update_leave_status_reject_after_approval(client, superadmin_user, employee_with_balance):
    headers = superadmin_user["headers"]
    employee = employee_with_balance["employee"]

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="casual",
        start_date=date.today(),
        end_date=date.today(),
        reason="Check rejection"
    )

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 200

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "rejected"},
        headers=headers
    )
    assert resp.status_code == 200
    assert "balance restored" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_no_permission(client, create_employee_success):
    """Current user is not superadmin/HR/manager → 401/403"""
    employee = await Employee.get(empid=create_employee_success["empid"])
    leave = await LeaveRequest.create(employee=employee, leave_type="casual", start_date=date.today(), end_date=date.today())

    headers = {"Authorization": "Bearer invalid_token"}  
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code in (401, 403)
    if resp.status_code == 403:
        assert "permission" in resp.text.lower()


@pytest.mark.asyncio
async def test_update_leave_status_already_rejected(client, superadmin_user, employee_with_leave):
    """Leave is already rejected → 400"""
    leave = employee_with_leave["leave"]
    leave.status = "rejected"
    await leave.save()

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "rejected"},
        headers=headers
    )
    assert resp.status_code == 400
    assert "already rejected" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_balance_not_found(client, superadmin_user, create_employee_success):
    """Leave balance not found → 404"""
    employee = await Employee.get(empid=create_employee_success["empid"])
    leave = await LeaveRequest.create(employee=employee, leave_type="casual", start_date=date.today(), end_date=date.today())

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 404
    assert "leave balance not found" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_zero_balance_deduction(client, superadmin_user, create_employee_success):
    """Current leave type balance is 0 → deduction returns 0"""
    employee = await Employee.get(empid=create_employee_success["empid"])
    balance = await LeaveBalance.create(
        employee=employee, sick_leave=0, casual_leave=0, earned_leave=0, optional_leave=0,
        total_sick_leave=0, total_casual_leave=0, total_earned_leave=0, total_optional_leave=0
    )
    leave = await LeaveRequest.create(employee=employee, leave_type="sick", start_date=date.today(), end_date=date.today())

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["deductions"]["sick"] == 0.0
    assert "leave_without_pay" in data 

@pytest.mark.asyncio
async def test_update_leave_status_insufficient_optional(client, superadmin_user, employee_with_balance):
    """Optional leave insufficient → API still approves (200)"""
    employee = employee_with_balance["employee"]
    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="optional",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=20) 
    )

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 200
    assert "leave approved" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_casual_deduction_priority(client, superadmin_user, employee_with_balance):
    """Deduct from casual if remaining > 0 and primary != casual"""
    employee = employee_with_balance["employee"]
    leave = await LeaveRequest.create(employee=employee, leave_type="sick",
                                      start_date=date.today(), end_date=date.today() + timedelta(days=3))
    headers = superadmin_user["headers"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["deductions"]["casual"] >= 0

@pytest.mark.asyncio
async def test_update_leave_status_earned_deduction_priority(client, superadmin_user, employee_with_balance):
    """Deduct from earned if remaining > 0 and primary != earned"""
    employee = employee_with_balance["employee"]
    leave = await LeaveRequest.create(employee=employee, leave_type="sick",
                                      start_date=date.today(), end_date=date.today() + timedelta(days=5))
    headers = superadmin_user["headers"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["deductions"]["earned"] >= 0

@pytest.mark.asyncio
async def test_update_leave_status_exception_handling(client, superadmin_user, monkeypatch, employee_with_leave):
    """Exception occurs → 500"""
    leave = employee_with_leave["leave"]

    async def fake_get_or_none(*args, **kwargs):
        raise Exception("DB error")

    monkeypatch.setattr("LMS.views.LeaveRequest.get_or_none", fake_get_or_none)

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 500
    assert "An error occurred" in resp.text


@pytest.mark.asyncio
async def test_update_leave_status_casual_priority(client, superadmin_user, employee_with_balance):
    """Deduct from casual if remaining > 0 and primary != casual"""
    employee = employee_with_balance["employee"]

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="sick",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=3)
    )

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    assert resp.status_code == 200
    data = resp.json()
    assert data["deductions"]["casual"] >= 0


@pytest.mark.asyncio
async def test_update_leave_status_earned_priority(client, superadmin_user, employee_with_balance):
    """Deduct from earned if remaining > 0 and primary != earned"""
    employee = employee_with_balance["employee"]

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="sick",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=5)
    )

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    assert resp.status_code == 200
    data = resp.json()
    assert data["deductions"]["earned"] >= 0


@pytest.mark.asyncio
async def test_update_leave_status_balance_not_found(client, superadmin_user, create_employee_success):
    """Leave balance not found → 404"""
    employee = await Employee.get(empid=create_employee_success["empid"])
    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="casual",
        start_date=date.today(),
        end_date=date.today()
    )

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    assert resp.status_code == 404
    assert "leave balance not found" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_permission_denied(client, create_employee_success, employee_with_token):
    """User not HR/manager/superadmin → 403"""
    employee = await Employee.get(empid=create_employee_success["empid"])
    leave = await LeaveRequest.create(
        employee=employee, leave_type="casual",
        start_date=date.today(), end_date=date.today()
    )

    headers = employee_with_token["headers"]   
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )
    assert resp.status_code == 403
    assert "permission" in resp.text.lower()

@pytest.mark.asyncio
async def test_update_leave_status_optional_insufficient(client, superadmin_user, employee_with_balance):
    employee = employee_with_balance["employee"]

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="optional",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=10)
    )

    balance = await LeaveBalance.get(employee=employee)
    balance.optional_leave = 0
    await balance.save()
    await balance.refresh_from_db()

    headers = superadmin_user["headers"]
    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    assert resp.status_code == 200
    assert "Leave approved" in resp.text

@pytest.mark.asyncio
async def test_update_leave_status_insufficient_optional_leave(client, superadmin_user, create_employee_success):
    """
    Optional leave insufficient → API still approves (200)
    """
    employee = await Employee.get(empid=create_employee_success["empid"])

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="optional",
        start_date=date.today(),
        end_date=date.today() + timedelta(days=10),
        reason="Festival"
    )

    balance = await LeaveBalance.create(
        employee=employee,
        sick_leave=5,
        casual_leave=5,
        earned_leave=5,
        optional_leave=2,  # insufficient
        total_sick_leave=5,
        total_casual_leave=5,
        total_earned_leave=5,
        total_optional_leave=2
    )

    headers = superadmin_user["headers"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    # API still approves
    assert resp.status_code == 200
    assert "leave approved" in resp.text.lower()


@pytest.mark.asyncio
async def test_update_leave_status_balance_not_found_raises_404(client, superadmin_user, create_employee_success):

    employee = await Employee.get(empid=create_employee_success["empid"])

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="sick",
        start_date=date.today(),
        end_date=date.today(),
        reason="Medical"
    )

    # Do NOT create LeaveBalance for this employee to trigger 404
    headers = superadmin_user["headers"]

    resp = await client.patch(
        f"/lms/admin/leave_status/{leave.id}",
        data={"status": "approved"},
        headers=headers
    )

    assert resp.status_code == 404
    assert "leave balance not found" in resp.text.lower()