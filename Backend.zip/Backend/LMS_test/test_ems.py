import pytest
import os
import sys
import mysql.connector
from mysql.connector import Error
from httpx import AsyncClient, ASGITransport
from fastapi import status
from passlib.context import CryptContext
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from main import app
from routes.employee_routes import get_current_user
transport = ASGITransport(app=app)
from LMS_test.conftest import login_user
from models import Employee
from User.models import User,EmployeeManagerMap
import io
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
import uuid
from conftest import transport, random_empid, random_email
from fastapi import status, HTTPException


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
transport = ASGITransport(app=app)

# ---------------------------logine-----------------------------
@pytest.mark.asyncio
async def test_hr_login(test_login_hr):
    assert test_login_hr is not None
    assert isinstance(test_login_hr, str)

@pytest.mark.asyncio
async def test_superadmin_login(test_login_superadmin):
    assert test_login_superadmin is not None
    assert isinstance(test_login_superadmin, str)

@pytest.mark.asyncio
async def test_manager_login(test_login_manager):
    assert test_login_manager is not None
    assert isinstance(test_login_manager, str)

@pytest.mark.asyncio
async def test_employee_login(employee_token):
    assert employee_token is not None
    assert isinstance(employee_token, str)

#  ---------------------------crate employee---------------------------


@pytest.mark.asyncio
async def test_create_employee(create_employee_success):#from conftest.py 
    password = create_employee_success
    assert password is not None


@pytest.mark.asyncio
async def test_create_employee_without_token(tmp_path):
    bad_file = tmp_path / "emp.png"
    bad_file.write_bytes(b"fake image data")

    app.dependency_overrides = {}

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(bad_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("emp.png", f, "image/png")},
                data={"name": "Test2_Emp", "email": "emp2@example.com", "empid": "E002"}
            )
    assert response.status_code == status.HTTP_401_UNAUTHORIZED


@pytest.mark.asyncio
async def test_create_employee_duplicate_id(tmp_path,test_login_hr):
    token =test_login_hr
    test_file = tmp_path / "photo.png"
    test_file.write_bytes(b"dummy image data")
    transport = ASGITransport(app=app)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            await ac.post(
                "/employee/",
                files={"file": ("photo.png", f, "image/png")},
                data={"name": "DupEmp", "email": "dup1@example.com", "empid": "dup001"},
                headers={"Authorization": f"Bearer {token}"}
            )

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("photo.png", f, "image/png")},
                data={"name": "DupEmp2", "email": "dup2@example.com", "empid": "dup001"},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_create_employee_invalid_file(tmp_path,test_login_hr):
    token = test_login_hr
    test_file = tmp_path / "doc.pdf"
    test_file.write_bytes(b"dummy pdf data")
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("doc.pdf", f, "application/pdf")},
                data={"name": "FileEmp", "email": "file_emp@example.com", "empid": "file001"},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_create_employee_invalid_manager(tmp_path,test_login_hr):
    token = test_login_hr
    test_file = tmp_path / "photo.png"
    test_file.write_bytes(b"dummy image data")
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("photo.png", f, "image/png")},
                data={"name": "EmpWithMgr", "email": "emp_mgr@example.com", "empid": "mgr001", "manager_email": "nonmanager@example.com"},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_hr_cannot_create_superadmin(tmp_path, test_login_hr):
    token = test_login_hr
    test_file = tmp_path / "hr_superadmin.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("hr_superadmin.png", f, "image/png")},
                data={"name": "HR Superadmin", "email": random_email(), "empid": random_empid(), "is_superadmin": True},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "HR cannot create superadmin" in response.text

@pytest.mark.asyncio
async def test_only_hr_or_superadmin_can_create(employee_token, tmp_path):
    token = employee_token
    test_file = tmp_path / "not_allowed.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("not_allowed.png", f, "image/png")},
                data={"name": "NormalUser", "email": random_email(), "empid": random_empid()},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "Only superadmin or HR can create users" in response.text


@pytest.mark.asyncio
async def test_missing_required_fields(test_login_hr, tmp_path):
    token = test_login_hr
    test_file = tmp_path / "missing.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("missing.png", f, "image/png")},
                data={"name": "", "email": "", "empid": ""},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "Name, email, file, and id are required" in response.text


@pytest.mark.asyncio
async def test_duplicate_email(create_employee_success, test_login_hr, tmp_path):
    token = test_login_hr
    existing_email = create_employee_success["email"]

    test_file = tmp_path / "dup_email.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("dup_email.png", f, "image/png")},
                data={"name": "Duplicate Email", "email": existing_email, "empid": random_empid()},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "already exists" in response.text


@pytest.mark.asyncio
async def test_invalid_manager(test_login_hr, tmp_path):
    token = test_login_hr
    test_file = tmp_path / "invalid_mgr.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("invalid_mgr.png", f, "image/png")},
                data={"name": "With Invalid Manager", "email": random_email(), "empid": random_empid(), "manager_email": "notexist@example.com"},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "invalid or not a manager" in response.text

@pytest.mark.asyncio
async def test_only_employees_can_have_manager(test_login_hr, tmp_path):
    """Test that assigning a non-employee as manager is not allowed"""
    token = test_login_hr
    non_employee_manager = "hr4mega@gmail.com"  
    test_file = tmp_path / "non_employee.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("non_employee.png", f, "image/png")},
                data={
                    "name": "Not Employee",
                    "email": random_email(),
                    "empid": random_empid(),
                    "manager_email": non_employee_manager,
                },
                headers={"Authorization": f"Bearer {token}"}
            )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "invalid or not a manager" in response.text



@pytest.mark.asyncio
async def test_invalid_file_type(test_login_hr, tmp_path):
    token = test_login_hr
    test_file = tmp_path / "invalid.txt"
    test_file.write_text("this is not an image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("invalid.txt", f, "text/plain")},
                data={"name": "Invalid File", "email": random_email(), "empid": random_empid()},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "Unsupported file type" in response.text


@pytest.mark.asyncio
async def test_internal_server_error(monkeypatch, test_login_hr, tmp_path):
    token = test_login_hr

    async def fake_create(*args, **kwargs):
        raise Exception("Simulated failure")
    monkeypatch.setattr(Employee, "create", fake_create)

    test_file = tmp_path / "fail.png"
    test_file.write_bytes(b"fake image")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("fail.png", f, "image/png")},
                data={"name": "Fail Employee", "email": random_email(), "empid": random_empid()},
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Internal server error" in response.text


@pytest.mark.asyncio
async def test_cannot_assign_self_as_manager(test_login_hr, tmp_path):
    """HR cannot assign themselves as their own manager"""
    token = test_login_hr
    test_file = tmp_path / "self_mgr.png"
    test_file.write_bytes(b"fake image")

    hr_user = await User.filter(is_hr=True).first()
    emp_id = f"E{uuid.uuid4().hex[:5]}"

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("self_mgr.png", f, "image/png")},
                data={
                    "name": "Self Manager",
                    "email": f"{uuid.uuid4().hex}@example.com",
                    "empid": emp_id,
                    "manager_email": hr_user.email 
                },
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "Provided manager is invalid or not a manager" in response.text


@pytest.mark.asyncio
async def test_only_employees_can_be_assigned_manager(test_login_hr, tmp_path):
    """Only employees can be assigned a manager"""
    token = test_login_hr
    test_file = tmp_path / "non_emp_mgr.png"
    test_file.write_bytes(b"fake image")

    non_employee_user = await User.filter(is_employee=False).first()
    emp_id = f"E{uuid.uuid4().hex[:5]}"

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("non_emp_mgr.png", f, "image/png")},
                data={
                    "name": "Non Employee Assigned Manager",
                    "email": f"{uuid.uuid4().hex}@example.com",
                    "empid": emp_id,
                    "manager_email": non_employee_user.email  
                },
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "Provided manager is invalid or not a manager" in response.text


@pytest.mark.asyncio
async def test_valid_manager_assignment(test_login_hr, tmp_path):
    """Valid employee manager assignment should succeed"""
    token = test_login_hr
    test_file = tmp_path / "valid_mgr.png"
    test_file.write_bytes(b"fake image")

    manager_email = f"mgr_{uuid.uuid4().hex}@example.com"
    manager_empid = f"MGR{uuid.uuid4().hex[:5]}"

    manager_emp = await Employee.create(name="Manager User", email=manager_email, empid=manager_empid, password="test")
    await User.create(email=manager_email, hashed_password="test", is_manager=True, is_employee=True, employee=manager_emp)

    emp_id = f"E{uuid.uuid4().hex[:5]}"
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("valid_mgr.png", f, "image/png")},
                data={
                    "name": "Employee With Manager",
                    "email": f"{uuid.uuid4().hex}@example.com",
                    "empid": emp_id,
                    "manager_email": manager_email
                },
                headers={"Authorization": f"Bearer {token}"}
            )
    assert response.status_code == status.HTTP_200_OK
    resp_json = response.json()
    assert resp_json["empid"] == emp_id
    assert resp_json["email"] != "" 
    assert resp_json["password"] != ""



# -------------------------add photo--------------------------------
@pytest.mark.asyncio
async def test_add_photo_success(add_photo_success):
    data = add_photo_success
    assert "photo_url" in data

@pytest.mark.asyncio
async def test_add_photo_unauthorized_user(employee_token, create_employee_success):
    empid = create_employee_success['empid']
    headers = {"Authorization": f"Bearer {employee_token}"}
    file_data = {"file": ("test.png", io.BytesIO(b"fake image"), "image/png")}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(f"/employee/addphoto/{empid}", files=file_data, headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "permission" in response.json()["detail"]

@pytest.mark.asyncio
async def test_add_photo_manager_not_allowed(test_login_manager, create_employee_success):
    empid = create_employee_success['empid']
    headers = {"Authorization": f"Bearer {test_login_manager}"}
    file_data = {"file": ("test.png", io.BytesIO(b"fake image"), "image/png")}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(f"/employee/addphoto/{empid}", files=file_data, headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "access" in response.json()["detail"]


@pytest.mark.asyncio
async def test_add_photo_invalid_file_type(test_login_hr, create_employee_success):
    empid = create_employee_success['empid']
    headers = {"Authorization": f"Bearer {test_login_hr}"}
    file_data = {"file": ("test.txt", io.BytesIO(b"not an image"), "text/plain")}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(f"/employee/addphoto/{empid}", files=file_data, headers=headers)

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "unsupported" in response.json()["detail"].lower()

@pytest.mark.asyncio
async def test_add_photo_employee_not_found(test_login_hr):
    empid = "NON_EXISTENT_EMP"
    headers = {"Authorization": f"Bearer {test_login_hr}"}
    file_data = {"file": ("test.png", io.BytesIO(b"fake image"), "image/png")}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(f"/employee/addphoto/{empid}", files=file_data, headers=headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert "employee not found" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_add_photo_internal_server_error(monkeypatch, test_login_hr, create_employee_success):
    empid = create_employee_success['empid']
    headers = {"Authorization": f"Bearer {test_login_hr}"}

    async def bad_get_or_none(*args, **kwargs):
        raise Exception("Simulated DB error")
    monkeypatch.setattr("models.Employee.get_or_none", bad_get_or_none)

    file_data = {"file": ("test.png", io.BytesIO(b"fake image"), "image/png")}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(f"/employee/addphoto/{empid}", files=file_data, headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "internal server error" in response.json()["detail"].lower()



# --------------------------------get photo----------------------

@pytest.mark.asyncio
async def test_get_photos_superadmin_success(test_login_superadmin):
    headers = {"Authorization": f"Bearer {test_login_superadmin}"}
    employee = await User.get(email="whonyu@example.com").prefetch_related("employee")
    emp = await employee.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/photos/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "urls" in data
    assert isinstance(data["urls"], list)


@pytest.mark.asyncio
async def test_get_photos_hr_success(test_login_hr):
    headers = {"Authorization": f"Bearer {test_login_hr}"}

    employee = await User.get(email="whonyu@example.com").prefetch_related("employee")
    emp = await employee.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/photos/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    assert "urls" in response.json()


@pytest.mark.asyncio
async def test_get_photos_manager_denied(test_login_manager):
    headers = {"Authorization": f"Bearer {test_login_manager}"}

    employee = await User.get(email="whonyu@example.com").prefetch_related("employee")
    emp = await employee.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/photos/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "access" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_get_photos_employee_forbidden(employee_token):
    headers = {"Authorization": f"Bearer {employee_token}"}

    employee = await User.get(email="whonyu@example.com").prefetch_related("employee")
    emp = await employee.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/photos/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "permission" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_get_photos_employee_not_found(test_login_superadmin):
    headers = {"Authorization": f"Bearer {test_login_superadmin}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/photos/NOEMP999", headers=headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert "not found" in response.json()["detail"].lower()

@pytest.mark.asyncio
async def test_get_photos_internal_server_error(monkeypatch, test_login_superadmin):
    headers = {"Authorization": f"Bearer {test_login_superadmin}"}

    async def mock_get_or_none(*args, **kwargs):
        raise Exception("Simulated DB failure")

    monkeypatch.setattr(Employee, "get_or_none", mock_get_or_none)

    empid = "E123456"  
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/photos/{empid}", headers=headers)

    assert response.status_code == 500
    data = response.json()
    assert "Internal server error" in data["detail"]

# ---------------------------------get all employees---------------------
@pytest.mark.asyncio
async def test_get_employees_superadmin(test_login_superadmin):
    token =  test_login_superadmin
    transport = ASGITransport(app=app)
    headers = {"Authorization": f"Bearer {token}"}
    
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/", headers=headers)
 
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "employees" in data
    assert len(data["employees"]) > 0


@pytest.mark.asyncio
async def test_get_employees_hr(test_login_hr):
    token = test_login_hr
    if not token:
        pytest.skip("HR token not available")

    transport = ASGITransport(app=app)
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "employees" in data
    assert len(data["employees"]) > 0

@pytest.mark.asyncio
async def test_get_employees_manager(test_login_manager):
    token = test_login_manager
    if not token:
        pytest.skip("Manager token not available")

    transport = ASGITransport(app=app)
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/", headers=headers)

    if response.status_code == 404:
        assert response.status_code == 404
    else:
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "employees" in data

@pytest.mark.asyncio
async def test_get_employees_forbidden_for_employee(employee_token):
    token = employee_token
    if not token:
        pytest.skip("Employee token not available")

    transport = ASGITransport(app=app)
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.asyncio
async def test_get_employees_internal_server_error(monkeypatch, test_login_superadmin):
    """
    Force an exception inside get_employees to check if 500 is returned.
    """
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

  

    async def mock_all():
        raise Exception("Simulated DB failure")

    monkeypatch.setattr(Employee, "all", mock_all)

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/", headers=headers)

    assert response.status_code == 500
    data = response.json()
    assert "Internal server error" in data["detail"]

# ---------------------------employee get by Id-----------------------------
@pytest.mark.asyncio
async def test_get_employee_superadmin_fetch_lol(test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    user = await User.get(email="lol@example.com").prefetch_related("employee")
    emp = await user.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "employee" in data
    assert data["employee"]["email"] == "lol@example.com"
    assert data["employee"]["empid"] == emp.empid


@pytest.mark.asyncio
async def test_get_employee_by_id_hr(test_login_hr):
    token = test_login_hr
    if not token:
        pytest.skip("HR token not available")

    user = await User.get(email="lol@example.com").prefetch_related("employee")
    emp = await user.employee

    headers = {"Authorization": f"Bearer {token}"}
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert data["employee"]["empid"] == emp.empid


@pytest.mark.asyncio
async def test_get_employee_by_id_manager(test_login_manager):
    token = test_login_manager
    if not token:
        pytest.skip("Manager token not available")

    user = await User.get(email="lol@example.com").prefetch_related("employee")
    emp = await user.employee

    headers = {"Authorization": f"Bearer {token}"}
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/{emp.empid}", headers=headers)

    if response.status_code == status.HTTP_403_FORBIDDEN:
        assert response.status_code == status.HTTP_403_FORBIDDEN
    else:
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["employee"]["empid"] == emp.empid


@pytest.mark.asyncio
async def test_get_employee_by_id_forbidden_for_employee(employee_token):
    token = employee_token
    if not token:
        pytest.skip("Employee token not available")

    user = await User.get(email="lol@example.com").prefetch_related("employee")
    emp = await user.employee

    headers = {"Authorization": f"Bearer {token}"}
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/{emp.empid}", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.asyncio
async def test_get_employee_by_id_internal_server_error(monkeypatch, test_login_superadmin):

    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    async def mock_get_or_none(*args, **kwargs):
        raise Exception("Simulated DB failure")

    monkeypatch.setattr(Employee, "get_or_none", mock_get_or_none)

    empid = "E999999"
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/{empid}", headers=headers)

    assert response.status_code == 500
    data = response.json()
    assert "Internal server error" in data["detail"]

# --------------------------change password--------------------------

@pytest.mark.asyncio
async def test_change_password_success_employee(create_employee_success,employee_token):
    employee = create_employee_success
    old_password = employee["password"]
    new_password = "newpass123"

    login_resp = await login_user(employee["email"], old_password)
    assert login_resp.status_code == 200
    token = employee_token

    headers = {"Authorization": f"Bearer {token}"}
    form_data = {"old_password": old_password, "new_password": new_password}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_200_OK
    assert response.json()["message"] == "Password changed successfully"

    updated_employee = await Employee.get(email=employee["email"])
    assert pwd_context.verify(new_password, updated_employee.password)

@pytest.mark.asyncio
async def test_change_password_invalid_old(employee_token):
    token = employee_token
    if not token:
        pytest.skip("Employee token not available")

    headers = {"Authorization": f"Bearer {token}"}
    form_data = {"old_password": "wrongpass", "new_password": "newpass123"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_401_UNAUTHORIZED
    assert response.json()["detail"] == "Incorrect old password"

@pytest.mark.asyncio
async def test_change_password_same_as_old(create_employee_success,employee_token):
    employee = create_employee_success
    old_password = employee["password"]
    new_password = old_password  # same as old

    login_resp = await login_user(employee["email"], old_password)
    assert login_resp.status_code == 200
    token = employee_token

    headers = {"Authorization": f"Bearer {token}"}
    form_data = {"old_password": old_password, "new_password": new_password}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert response.json()["detail"] == "New password must be different from the old password"

@pytest.mark.asyncio
async def test_change_password_forbidden_for_non_employee(test_login_hr):
    old_password = "HRpass123"
    new_password = "newpass123"

    headers = {"Authorization": f"Bearer {test_login_hr}"}
    form_data = {"old_password": old_password, "new_password": new_password}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_401_UNAUTHORIZED

@pytest.mark.asyncio
async def test_change_password_user_not_found(employee_token, monkeypatch):
    """Test password change when user does not exist in DB"""
    token = employee_token
    headers = {"Authorization": f"Bearer {token}"}
    form_data = {"old_password": "anyoldpass", "new_password": "newpass123"}

    async def fake_get_or_none(*args, **kwargs):
        return None

    monkeypatch.setattr("User.models.User.get_or_none", fake_get_or_none)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "User not found"


@pytest.mark.asyncio
async def test_change_password_internal_server_error(create_employee_success, employee_token, monkeypatch):
    """Test password change triggers internal server error"""
    employee = create_employee_success
    old_password = employee["password"]
    new_password = "newpass123"
    token = employee_token

    headers = {"Authorization": f"Bearer {token}"}
    form_data = {"old_password": old_password, "new_password": new_password}

    async def fake_save(*args, **kwargs):
        raise Exception("Database failure")

    monkeypatch.setattr("User.models.User.save", fake_save)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Internal server error" in response.json()["detail"]

@pytest.mark.asyncio
async def test_change_password_user_not_in_db(employee_token, monkeypatch):
    """
    Test changing password when the user does not exist in the database.
    Should raise 404 User not found.
    """
    token = employee_token
    headers = {"Authorization": f"Bearer {token}"}
    form_data = {"old_password": "anyoldpass", "new_password": "newpass123"}

    async def fake_get_or_none(*args, **kwargs):
        return None

    monkeypatch.setattr("User.models.User.get_or_none", fake_get_or_none)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/employee/change-password", data=form_data, headers=headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "User not found"
# ---------------------------update employee-----------------------------

@pytest.mark.asyncio
async def test_update_employee_success(tmp_path, create_employee_success, test_login_hr):
    emp_data = create_employee_success
    empid = emp_data["empid"]
    email = emp_data["email"]
    token = test_login_hr

    new_file = tmp_path / "new_photo.png"
    new_file.write_bytes(b"new dummy data")

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(new_file, "rb") as f:
            response = await ac.patch(
                "/employee/update-employee",
                data={
                    "empid": empid,
                    "name": "UpdatedName",
                    "email": f"updated_{email}",
                    "is_manager": True
                },
                files={"file": ("new_photo.png", f, "image/png")},
                headers={"Authorization": f"Bearer {token}"}
            )

    assert response.status_code == status.HTTP_200_OK, response.text
    
    user_in_db = await User.get_or_none(email=f"updated_{email}")
    assert user_in_db is not None
    assert user_in_db.is_manager


@pytest.mark.asyncio
async def test_update_employee_unauthorized(create_employee_success, employee_token):
    empid = create_employee_success["empid"]
    headers = {"Authorization": f"Bearer {employee_token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "name": "HackName"},
            headers=headers
        )

    assert resp.status_code == status.HTTP_403_FORBIDDEN
    assert "only superadmin or hr" in resp.json()["detail"].lower()



@pytest.mark.asyncio
async def test_update_employee_duplicate_email(tmp_path, test_login_hr):
    token = test_login_hr

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        emp1_file = tmp_path / "emp1.png"
        emp1_file.write_bytes(b"dummy data")
        with open(emp1_file, "rb") as f1:
            await ac.post(
                "/employee/",
                data={"name": "Emp1", "email": "dup_email1@example.com", "empid": "dup01"},
                files={"file": ("emp1.png", f1, "image/png")},
                headers={"Authorization": f"Bearer {token}"}
            )

        emp2_file = tmp_path / "emp2.png"
        emp2_file.write_bytes(b"dummy data")
        with open(emp2_file, "rb") as f2:
            await ac.post(
                "/employee/",
                data={"name": "Emp2", "email": "dup_email2@example.com", "empid": "dup02"},
                files={"file": ("emp2.png", f2, "image/png")},
                headers={"Authorization": f"Bearer {token}"}
            )

        response = await ac.patch(
            "/employee/update-employee",
            data={"empid": "dup02", "email": "dup_email1@example.com"},
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST


@pytest.mark.asyncio
async def test_update_employee_not_found(test_login_hr):
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.patch(
            "/employee/update-employee",
            data={"empid": "NON_EXISTENT", "name": "Nobody"},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.asyncio
async def test_update_employee_linked_user_not_found(create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    token = test_login_hr

    user = await User.get(employee__empid=empid)
    await user.delete()

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "name": "NewName"},
            headers={"Authorization": f"Bearer {token}"}
        )

    assert resp.status_code == status.HTTP_404_NOT_FOUND
    assert "linked user not found" in resp.json()["detail"].lower()


@pytest.mark.asyncio
async def test_update_employee_user_email_conflict(create_employee_success, create_manager_success, test_login_hr):
    empid = create_employee_success["empid"]
    email_taken = create_manager_success["email"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "email": email_taken},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert response.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_update_employee_set_superadmin(create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    email = create_employee_success["email"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "is_superadmin": True},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp.status_code == status.HTTP_200_OK
    user = await User.get_or_none(email=email)
    assert user.is_superadmin is True

@pytest.mark.asyncio
async def test_update_employee_set_hr(create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    email = create_employee_success["email"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "is_hr": True},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp.status_code == status.HTTP_200_OK
    user = await User.get_or_none(email=email)
    assert user.is_hr is True

@pytest.mark.asyncio
async def test_update_employee_invalid_manager(create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "manager_email": "notamanager@example.com"},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_update_employee_self_as_manager(create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    email = create_employee_success["email"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "manager_email": email},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_update_employee_manager_assign_non_employee(create_manager_success, test_login_hr):
    empid = create_manager_success["empid"]
    manager_email = create_manager_success["email"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "manager_email": manager_email},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_update_employee_manager_mapping_create_and_update(create_employee_success, create_manager_success, test_login_hr):
    empid = create_employee_success["empid"]
    token = test_login_hr
    manager_email = create_manager_success["email"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp1 = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "manager_email": manager_email},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp1.status_code == status.HTTP_200_OK
    mapping = await EmployeeManagerMap.get_or_none(employee__empid=empid)
    assert mapping is not None

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp2 = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "manager_email": manager_email},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp2.status_code == status.HTTP_200_OK

@pytest.mark.asyncio
async def test_update_employee_invalid_file_type(create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    token = test_login_hr
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid},
            files={"file": ("bad.txt", io.BytesIO(b"junk"), "text/plain")},
            headers={"Authorization": f"Bearer {token}"}
        )
    assert resp.status_code == status.HTTP_400_BAD_REQUEST

@pytest.mark.asyncio
async def test_update_employee_internal_server_error(monkeypatch, create_employee_success, test_login_hr):
    empid = create_employee_success["empid"]
    token = test_login_hr

    async def bad_save(*args, **kwargs):
        raise Exception("Simulated failure in save")

    monkeypatch.setattr(Employee, "save", bad_save)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "name": "ShouldFail"},
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "internal server error" in response.json()["detail"].lower()

@pytest.mark.asyncio
async def test_update_employee_email_conflict_with_another_user(create_employee_success, create_manager_success, test_login_hr):
    empid = create_employee_success["empid"]
    email_taken = create_manager_success["email"]
    token = test_login_hr

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "email": email_taken},
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "another employee already uses this email" in response.json()["detail"].lower()

@pytest.mark.asyncio
async def test_update_employee_manager_assign_non_employee_role(create_manager_success, test_login_hr):
    empid = create_manager_success["empid"]
    manager_email = create_manager_success["email"]
    token = test_login_hr

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.patch(
            "/employee/update-employee",
            data={"empid": empid, "manager_email": manager_email},
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    detail = response.json()["detail"].lower()
    assert ("only those who are employee" in detail) or ("cannot assign yourself as your own manager" in detail)

# -------------------------get managers--------------------------------

@pytest.mark.asyncio
async def test_get_managers_success_superadmin(test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers", headers=headers)

    assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    if response.status_code == status.HTTP_200_OK:
        data = response.json()
        assert isinstance(data, list)


@pytest.mark.asyncio
async def test_get_managers_success_hr(test_login_hr):
    token = test_login_hr
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers", headers=headers)

    assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    if response.status_code == status.HTTP_200_OK:
        data = response.json()
        assert isinstance(data, list)


@pytest.mark.asyncio
async def test_get_managers_forbidden_manager(test_login_manager):
    token = test_login_manager
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers", headers=headers)

    assert response.status_code in [status.HTTP_403_FORBIDDEN, status.HTTP_404_NOT_FOUND]


@pytest.mark.asyncio
async def test_get_managers_forbidden_employee(employee_token):
    token = employee_token
    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.mark.asyncio
async def test_get_managers_internal_server_error(monkeypatch, test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    async def fake_filter(*args, **kwargs):
        raise Exception("Simulated DB error")
    monkeypatch.setattr(User, "filter", fake_filter)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers/", headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "internal server error" in response.json()["detail"].lower()


# @pytest.mark.asyncio
# async def test_get_managers_forbidden_non_hr_superadmin(employee_token):

#     headers = {"Authorization": f"Bearer {employee_token}"}
#     async with AsyncClient(transport=transport, base_url="http://test") as ac:
#         response = await ac.get("/employee/managers/", headers=headers)

#     assert response.status_code == status.HTTP_403_FORBIDDEN
#     assert "don't have permission" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_get_managers_returns_list(test_login_superadmin):
    """
    Test that the API returns a list of managers for HR or superadmin
    """
    headers = {"Authorization": f"Bearer {test_login_superadmin}"}
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers/", headers=headers)

    assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    if response.status_code == status.HTTP_200_OK:
        data = response.json()
        assert isinstance(data, list)


@pytest.mark.asyncio
async def test_get_managers_internal_server_error(monkeypatch, test_login_hr):
    """
    Test that internal exceptions return 500
    """
    headers = {"Authorization": f"Bearer {test_login_hr}"}

    async def fake_filter(*args, **kwargs):
        raise Exception("Simulated DB error")

    monkeypatch.setattr(User, "filter", fake_filter)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers/", headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "internal server error" in response.json()["detail"].lower()

@pytest.mark.asyncio
async def test_get_managers_http_exception_reraised(monkeypatch, test_login_hr):
    """
    Test that HTTPException is re-raised as-is
    """
    headers = {"Authorization": f"Bearer {test_login_hr}"}

    class FakeQuery:
        async def all(self):
            raise HTTPException(status_code=403, detail="Custom HTTPException")

        def prefetch_related(self, *args, **kwargs):
            return self

    monkeypatch.setattr(User, "filter", lambda *args, **kwargs: FakeQuery())

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get("/employee/managers/", headers=headers)

    assert response.status_code == 403
    assert "custom httpexception" in response.json()["detail"].lower()



# -------------------------get manger employee by Id--------------------------------

@pytest.mark.asyncio
async def test_get_manager_employees_as_superadmin(create_manager_success, test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}
    manager_empid = create_manager_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/manager_employee/{manager_empid}", headers=headers)

    assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    if response.status_code == 200:
        assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_get_manager_employees_as_hr(create_manager_success, test_login_hr):
    token = test_login_hr
    headers = {"Authorization": f"Bearer {token}"}
    manager_empid = create_manager_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/manager_employee/{manager_empid}", headers=headers)

    assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    if response.status_code == 200:
        assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_get_manager_employees_as_manager(create_manager_success, test_login_manager):
    token = test_login_manager
    headers = {"Authorization": f"Bearer {token}"}
    manager_empid = create_manager_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/manager_employee/{manager_empid}", headers=headers)

    assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    if response.status_code == 200:
        assert isinstance(response.json(), list)


@pytest.mark.asyncio
async def test_get_manager_employees_as_employee(create_manager_success, employee_token):
    token = employee_token
    headers = {"Authorization": f"Bearer {token}"}
    manager_empid = create_manager_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/manager_employee/{manager_empid}", headers=headers)

    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.mark.asyncio
async def test_get_manager_employees_invalid_manager(test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}
    invalid_empid = "EMP99999"  

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/manager_employee/{invalid_empid}", headers=headers)

    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.asyncio
async def test_get_manager_employees_internal_server_error(monkeypatch, test_login_superadmin, create_manager_success):
    """
    Simulate internal server error when fetching employees under a manager.
    """
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}

    from User.models import Employee

    async def fake_filter(*args, **kwargs):
        raise Exception("Simulated DB error")
    monkeypatch.setattr(Employee, "filter", fake_filter)

    manager_empid = create_manager_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.get(f"/employee/manager_employee/{manager_empid}", headers=headers)

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Internal server error" in response.text


# -------------------------delete photo--------------------------------

@pytest.mark.asyncio
async def test_delete_photo_success(add_photo_success):
    empid = add_photo_success["empid"]
    headers = add_photo_success["headers"]
    file_name = add_photo_success["file_name"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/deletephoto/{empid}",
            data={"file": file_name},
            headers=headers
        )

    assert response.status_code == status.HTTP_200_OK
    assert "successfully" in response.json()["message"].lower()


@pytest.mark.asyncio
async def test_delete_photo_unauthorized(employee_token, add_photo_success):
    empid = add_photo_success["empid"]
    headers = {"Authorization": f"Bearer {employee_token}"}
    file_name = add_photo_success["file_name"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/deletephoto/{empid}",
            data={"file": file_name},
            headers=headers
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "permission" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_delete_photo_employee_not_found(test_login_hr):
    headers = {"Authorization": f"Bearer {test_login_hr}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            "/employee/deletephoto/EMP_DOES_NOT_EXIST",
            data={"file": "fake.png"},
            headers=headers
        )

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert "employee not found" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_delete_photo_manager_not_mapped(test_login_manager, add_photo_success):
    empid = add_photo_success["empid"]
    headers = {"Authorization": f"Bearer {test_login_manager}"}
    file_name = add_photo_success["file_name"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/deletephoto/{empid}",
            data={"file": file_name},
            headers=headers
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert "access" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_delete_photo_file_not_found(add_photo_success):
    empid = add_photo_success["empid"]
    headers = add_photo_success["headers"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/deletephoto/{empid}",
            data={"file": "nonexistent.png"},
            headers=headers
        )

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert "file not found" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_delete_photo_last_photo_not_allowed(add_photo_success, monkeypatch):
    empid = add_photo_success["empid"]
    headers = add_photo_success["headers"]
    file_name = add_photo_success["file_name"]

    monkeypatch.setattr(os, "listdir", lambda path: [file_name])
    
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/deletephoto/{empid}",
            data={"file": file_name},
            headers=headers
        )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "at least one photo must remain" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_delete_photo_internal_server_error(monkeypatch, add_photo_success):
    empid = add_photo_success["empid"]
    headers = add_photo_success["headers"]
    file_name = add_photo_success["file_name"]

    def fake_remove(path):
        raise Exception("Disk failure")
    monkeypatch.setattr(os, "remove", fake_remove)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/deletephoto/{empid}",
            data={"file": file_name},
            headers=headers
        )

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "internal server error" in response.json()["detail"].lower()
# -------------------------delete photo--------------------------------

@pytest.mark.asyncio
async def test_delete_employee_superadmin(test_login_superadmin, create_employee_success):
    token = test_login_superadmin
    emp_data = create_employee_success

    emp = await Employee.get_or_none(empid=emp_data["empid"])
    user = await User.get_or_none(email=emp_data["email"])

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_200_OK
    assert await Employee.get_or_none(empid=emp.empid) is None
    assert await User.get_or_none(id=user.id) is None


@pytest.mark.asyncio
async def test_delete_employee_hr(test_login_hr, create_employee_success):
    token = test_login_hr
    emp_data = create_employee_success

    emp = await Employee.get_or_none(empid=emp_data["empid"])
    user = await User.get_or_none(email=emp_data["email"])

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_200_OK
    assert await Employee.get_or_none(empid=emp.empid) is None


@pytest.mark.asyncio
async def test_delete_employee_manager_cannot_delete(test_login_manager, create_employee_success):
    token = test_login_manager
    emp_data = create_employee_success

    emp = await Employee.get_or_none(empid=emp_data["empid"])

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.mark.asyncio
async def test_delete_employee_cannot_delete_self(test_login_hr, create_employee_success):
    token = test_login_hr

    hr_user = await User.filter(is_hr=True).first()
    assert hr_user is not None
    emp = await hr_user.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.mark.asyncio
async def test_delete_employee_not_found(test_login_superadmin):
    """Test deleting an employee that does not exist"""
    token = test_login_superadmin
    non_existent_empid = "NONEXIST123"

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{non_existent_empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_404_NOT_FOUND
    assert response.json()["detail"] == "Employee not found"

@pytest.mark.asyncio
async def test_delete_employee_cannot_delete_self_employee(create_employee_success, employee_token):
    """Employee cannot delete themselves"""
    token = employee_token
    emp_data = create_employee_success

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp_data['empid']}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert response.json()["detail"] == "Only Superadmin or HR can delete an employee"




@pytest.mark.asyncio
async def test_delete_employee_internal_server_error(test_login_superadmin, monkeypatch, create_employee_success):
    """Test that an internal exception returns HTTP 500"""
    token = test_login_superadmin
    emp_data = create_employee_success

    emp = await Employee.get_or_none(empid=emp_data["empid"])
    user = await User.get_or_none(email=emp_data["email"])

    async def fake_delete(*args, **kwargs):
        raise Exception("DB failure")

    monkeypatch.setattr(User, "delete", fake_delete)

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR
    assert "Internal server error" in response.json()["detail"]

@pytest.mark.asyncio
async def test_delete_employee_cannot_delete_superadmin(test_login_hr):
    """
    Test that HR or others cannot delete a superadmin.
    API returns: "Cannot delete a Superadmin".
    """
    token = test_login_hr
    superadmin_user = await User.filter(is_superadmin=True).first()
    emp = await superadmin_user.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert response.json()["detail"] == "Cannot delete a Superadmin"

@pytest.mark.asyncio
async def test_delete_employee_cannot_delete_self_superadmin(test_login_superadmin):
    """
    Test that a superadmin cannot delete themselves.
    API returns: "Cannot delete a Superadmin" (not "You cannot delete yourself").
    """
    token = test_login_superadmin
    superadmin_user = await User.filter(is_superadmin=True).first()
    emp = await superadmin_user.employee

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.delete(
            f"/employee/delete-employee/{emp.empid}",
            headers={"Authorization": f"Bearer {token}"}
        )

    assert response.status_code == status.HTTP_403_FORBIDDEN
    assert response.json()["detail"] == "Cannot delete a Superadmin"
