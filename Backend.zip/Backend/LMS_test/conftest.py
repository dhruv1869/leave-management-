import sys
import os


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

print("PYTHONPATH:", sys.path)  

from main import app
import pytest_asyncio
import pytest
import mysql.connector
from httpx import AsyncClient, ASGITransport
from tortoise import Tortoise
from fastapi import status
from User.models import User
import io
from LMS.models import LeaveBalance
from models import Employee

transport = ASGITransport(app=app)

transport = ASGITransport(app=app)

DB_URL = "mysql://root:root@localhost:3306/lms_test"

@pytest_asyncio.fixture(scope="function", autouse=True)
async def init_db():
    await Tortoise.init(
        db_url=DB_URL,
        modules={"models": ["models", "User.models", "LMS.models"]},
    )
    yield
    await Tortoise.close_connections()

# MySQL connection 
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="lms_test"
)
cursor = conn.cursor(dictionary=True)

async def login_user(email, password):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post("/users/login", json={"email": email, "password": password})
    return response

import random
import pytest_asyncio
import random
import pytest_asyncio

@pytest_asyncio.fixture
async def create_hr_success(tmp_path, test_login_superadmin):
    token = test_login_superadmin

    test_file = tmp_path / "photo.png"
    test_file.write_bytes(
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
        b"\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x02\x00\x00\x00\x90wS\xde"
        b"\x00\x00\x00\nIDATx\xdac\xf8\x0f\x00\x01\x01\x01\x00"
        b"\x18\xdd\x8d\xa5\x00\x00\x00\x00IEND\xaeB`\x82"
    )

    empid = random_empid()
    email = random_email()

    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("photo.png", f, "image/png")},
                data={
                    "name": "Test Employee",
                    "email": email,
                    "empid": empid,
                    "is_hr": True
                },
                headers=headers
            )

    assert response.status_code == status.HTTP_200_OK, response.text

    data = response.json()
    password = data["password"]

    login_resp = await login_user(email, password)
    assert login_resp.status_code == 200

    return {
    "empid": empid,
    "email": email,
    "password": password
    }


@pytest_asyncio.fixture
async def create_manager_success(tmp_path, test_login_superadmin):
    token = test_login_superadmin

    test_file = tmp_path / "manager.png"
    test_file.write_bytes(
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
        b"\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x02\x00\x00\x00\x90wS\xde"
        b"\x00\x00\x00\nIDATx\xdac\xf8\x0f\x00\x01\x01\x01\x00"
        b"\x18\xdd\x8d\xa5\x00\x00\x00\x00IEND\xaeB`\x82"
    )

    empid = random_empid()
    email = random_email()

    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("manager.png", f, "image/png")},
                data={
                    "name": "Test Manager",
                    "email": email,
                    "empid": empid,
                    "is_manager": True,   
                },
                headers=headers,
            )

    assert response.status_code == status.HTTP_200_OK, response.text

    data = response.json()
    password = data["password"]

    login_resp = await login_user(email, password)
    assert login_resp.status_code == 200

    return {
        "empid": empid,
        "email": email,
        "password": password,
        "headers": headers,
    }


@pytest_asyncio.fixture
async def test_login_superadmin():
    email="superadmin@gmail.com"
    password="superadmin"

    resp = await login_user(email, password)
    assert resp.status_code == 200
    return resp.json()["access_token"]


@pytest_asyncio.fixture
async def test_login_hr(create_hr_success):
    email = create_hr_success["email"]
    password = create_hr_success["password"]

    resp = await login_user(email, password)
    assert resp.status_code == 200
    return resp.json()["access_token"]

@pytest_asyncio.fixture
async def test_login_manager(create_manager_success):
    email = create_manager_success["email"]
    password = create_manager_success["password"]

    resp = await login_user(email, password)
    assert resp.status_code == 200
    return resp.json()["access_token"]

import secrets
import string
def random_empid():
    return f"E{secrets.randbelow(999999)}"

def random_email():
    rand = ''.join(secrets.choice(string.ascii_lowercase) for _ in range(6))
    return f"{rand}@example.com"

@pytest_asyncio.fixture
async def create_employee_success(tmp_path, test_login_hr):
    token = test_login_hr

    test_file = tmp_path / "photo.png"
    test_file.write_bytes(
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
        b"\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x02\x00\x00\x00\x90wS\xde"
        b"\x00\x00\x00\nIDATx\xdac\xf8\x0f\x00\x01\x01\x01\x00"
        b"\x18\xdd\x8d\xa5\x00\x00\x00\x00IEND\xaeB`\x82"
    )

    empid = random_empid()
    email = random_email()

    headers = {"Authorization": f"Bearer {token}"}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        with open(test_file, "rb") as f:
            response = await ac.post(
                "/employee/",
                files={"file": ("photo.png", f, "image/png")},
                data={
                    "name": "Test Employee",
                    "email": email,
                    "empid": empid
                },
                headers=headers
            )

    assert response.status_code == status.HTTP_200_OK, response.text

    data = response.json()
    password = data["password"]

    login_resp = await login_user(email, password)
    assert login_resp.status_code == 200

    return {
    "empid": empid,
    "email": email,
    "password": password
    }

@pytest_asyncio.fixture
async def employee_token(create_employee_success):
    employee = create_employee_success
    email = employee["email"]
    password = employee["password"]

    resp = await login_user(email, password)

    assert resp.status_code == 200, f"Login failed: {resp.status_code} - {getattr(resp, 'text', '')}"
    token = resp.json().get("access_token")
    assert token, "No access_token returned in login response."
    return token


@pytest_asyncio.fixture
async def add_photo_success(create_employee_success, test_login_hr):
    empid = create_employee_success['empid']
    headers = {"Authorization": f"Bearer {test_login_hr}"}
    file_data = {"file": ("test.png", io.BytesIO(b"valid image"), "image/png")}

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        response = await ac.post(
            f"/employee/addphoto/{empid}",
            files=file_data,
            headers=headers
        )
        
    assert response.status_code == status.HTTP_200_OK
    data = response.json()
    assert "photo_url" in data

    photo_url = data["photo_url"]
    file_name = photo_url.split("/")[-1]
    
    return {
        "empid": empid,
        "headers": headers,
        "file_name": file_name,
        "photo_url": photo_url
    }


def teardown_module(module):
    cursor.close()
    conn.close()


@pytest_asyncio.fixture
async def employee_with_balance(create_employee_success):
    """
    Fixture to return headers for an employee who has leave balance set.
    """
    emp_email = create_employee_success["email"]
    emp_password = create_employee_success["password"]
    empid = create_employee_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        login_resp = await ac.post("/users/login", json={"email": emp_email, "password": emp_password})
    
    emp_token = login_resp.json()["access_token"]
    emp_headers = {"Authorization": f"Bearer {emp_token}"}

    employee = await Employee.get(empid=empid)
    await LeaveBalance.create(
        employee=employee,
        sick_leave=10,
        casual_leave=10,
        optional_leave=10,
        earned_leave=10,
        total_sick_leave=10,
        total_casual_leave=10,
        total_optional_leave=10,
        total_earned_leave=10
    )

    return {
        "employee": employee,
        "headers": emp_headers
    }

import pytest_asyncio
from datetime import date, timedelta
from httpx import AsyncClient, ASGITransport
from LMS.models import LeaveRequest, LeaveBalance  
from main import app

transport = ASGITransport(app=app)


@pytest_asyncio.fixture
async def employee_with_leave_and_balance(create_employee_success):
    """
    Fixture: returns an employee with leave balance and one leave request.
    """
    emp_email = create_employee_success["email"]
    emp_password = create_employee_success["password"]
    empid = create_employee_success["empid"]

    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        login_resp = await ac.post("/users/login", json={"email": emp_email, "password": emp_password})
    
    emp_token = login_resp.json()["access_token"]
    emp_headers = {"Authorization": f"Bearer {emp_token}"}

    employee = await Employee.get(empid=empid)

    await LeaveBalance.create(
        employee=employee,
        sick_leave=10,
        casual_leave=10,
        optional_leave=10,
        earned_leave=10,
        total_sick_leave=10,
        total_casual_leave=10,
        total_optional_leave=10,
        total_earned_leave=10
    )

    leave = await LeaveRequest.create(
        employee=employee,
        leave_type="casual",
        start_date=date.today() + timedelta(days=1),
        end_date=date.today() + timedelta(days=2),
        reason="Family function"
    )

    return {
        "employee": employee,
        "headers": emp_headers,
        "leave": leave
    }


@pytest_asyncio.fixture
async def employee_with_leave(employee_with_leave_and_balance):

    return employee_with_leave_and_balance

@pytest_asyncio.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac

@pytest_asyncio.fixture
async def superadmin_user(test_login_superadmin):
    token = test_login_superadmin
    headers = {"Authorization": f"Bearer {token}"}
    return {"headers": headers}


@pytest_asyncio.fixture
async def employee_with_token(create_employee_success, client):
    email = create_employee_success["email"]
    password = create_employee_success["password"]

    response = await client.post("/users/login", json={"email": email, "password": password})
    assert response.status_code == 200
    token = response.json()["access_token"]

    headers = {"Authorization": f"Bearer {token}"}

    return {"employee": create_employee_success, "headers": headers}

@pytest_asyncio.fixture
async def normal_user(init_db):
    user = await User.create(
        username="normaluser",
        email="normaluser@example.com"
    )
    headers = {"Authorization": f"Bearer {user.id}"}
    return {"user": user, "headers": headers}
