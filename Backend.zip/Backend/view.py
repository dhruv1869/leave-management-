# from fastapi import APIRouter, Form, HTTPException
# from models import User
# from auth import create_access_token
# from utils import verify_password
# from passlib.context import CryptContext


# router = APIRouter()

# @router.post("/login")
# async def login(email: str = Form(...), password: str = Form(...)):
#     user = await User.get_or_none(email=email)
#     if not user or not verify_password(password, user.password):
#         raise HTTPException(status_code=401, detail="Invalid credentials")

#     access_token = create_access_token(data={"sub": user.username})
#     return {"access_token": access_token, "token_type": "bearer"}
