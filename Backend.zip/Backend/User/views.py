from fastapi import APIRouter, HTTPException, Depends
from typing import List
from User.models import User
from utils import decode_access_token, create_token, hash_password, verify_password
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr
from typing import Optional

# class UserCreate(BaseModel):
#     email: EmailStr
#     username: str
#     password: str
#     is_superadmin: Optional[bool] = False
#     is_hr: Optional[bool] = False
#     is_manager: Optional[bool] = False
#     is_employee: Optional[bool] = False

# class UserUpdate(BaseModel):
#     username: Optional[str]
#     password: Optional[str]
#     is_superuser: Optional[bool]
#     is_hr: Optional[bool]
#     is_manager: Optional[bool]
#     is_employee: Optional[bool]

# class UserOut(BaseModel):
#     id: int
#     email: EmailStr
#     username: str
#     is_superadmin: bool
#     is_hr: bool
#     is_manager: bool
#     is_employee: bool

#     class Config:
#         orm_mode = True

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    username: str
    access_token: str
    token_type: str = "bearer"

router = APIRouter(prefix="/users", tags=["Users"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login")

async def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await User.get_or_none(email=payload["sub"])
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# async def require_superadmin(user: User = Depends(get_current_user)):
#     if not user.is_superadmin:
#         raise HTTPException(status_code=403, detail="Only superadmin allowed")
#     return user

# eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzdXBlcmFkbWluQGdtYWlsLmNvbSIsImV4cCI6MTc1ODE5Mzk1N30.FWN-gBH_lH8YjRiW7C9XWKZ7mpbnkkhSbUeyhJduTLU
@router.post("/login", response_model=TokenResponse)
async def login(data: LoginRequest):
    try:
        user = await User.get_or_none(email=data.email)
        if not user or not verify_password(data.password, user.hashed_password):
            raise HTTPException(status_code=401, detail="Invalid email or password")

        token = create_token({"sub": user.email})
        return {"username": user.email,"access_token": token}
    
    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


# # CREATE
# @router.post("/", response_model=UserOut)
# async def create_user(data: UserCreate, current_user: User = Depends(get_current_user)):
#     # Restrict HR from creating superadmin
#     if current_user.is_hr and data.is_superadmin:
#         raise HTTPException(status_code=403, detail="HR cannot create superadmin")

#     if not current_user.is_superadmin and not current_user.is_hr:
#         raise HTTPException(status_code=403, detail="Only superadmin or HR can create users")

#     if current_user.is_hr:
#         if not data.is_employee or any([data.is_superadmin, data.is_hr, data.is_manager]):
#             raise HTTPException(status_code=403, detail="HR can only create employee accounts")

#     existing = await User.get_or_none(email=data.email)
#     if existing:
#         raise HTTPException(status_code=400, detail="Email already exists")
#     user = await User.create(
#         email=data.email,
#         username=data.username,
#         hashed_password=hash_password(data.password),
#         is_superadmin=data.is_superadmin,
#         is_hr=data.is_hr,
#         is_manager=data.is_manager,
#         is_employee=data.is_employee,
#     )
#     return user

# # READ ALL
# @router.get("/", response_model=List[UserOut])
# async def get_all_users(_: User = Depends(require_superadmin)):
#     return await User.all()

# # READ ONE
# @router.get("/{user_id}", response_model=UserOut)
# async def get_user(user_id: int, _: User = Depends(require_superadmin)):
#     user = await User.get_or_none(id=user_id)
#     if not user:
#         raise HTTPException(status_code=404, detail="User not found")
#     return user

# # UPDATE
# @router.put("/{user_id}", response_model=UserOut)
# async def update_user(user_id: int, data: UserUpdate, _: User = Depends(require_superadmin)):
#     user = await User.get_or_none(id=user_id)
#     if not user:
#         raise HTTPException(status_code=404, detail="User not found")

#     if data.password:
#         user.hashed_password = User.hash_password(data.password)
#     for field, value in data.dict(exclude_unset=True, exclude={"password"}).items():
#         setattr(user, field, value)
#     await user.save()
#     return user

# # DELETE
# @router.delete("/{user_id}")
# async def delete_user(user_id: int, _: User = Depends(require_superadmin)):
#     user = await User.get_or_none(id=user_id)
#     if not user:
#         raise HTTPException(status_code=404, detail="User not found")
#     await user.delete()
#     return {"message": "User deleted successfully"}
