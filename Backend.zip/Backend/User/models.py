from tortoise import fields
from tortoise.models import Model
from models import Employee

class User(Model):
    id = fields.IntField(pk=True)
    email = fields.CharField(max_length=255, unique=True)
    hashed_password = fields.CharField(max_length=255)
    is_superadmin = fields.BooleanField(default=False)
    is_hr = fields.BooleanField(default=False)
    is_manager = fields.BooleanField(default=False)
    is_employee = fields.BooleanField(default=True)

    employee: fields.ForeignKeyNullableRelation["Employee"] = fields.ForeignKeyField(
        "models.Employee", related_name="user", null=True, on_delete=fields.SET_NULL
    )
    
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now= True)

class EmployeeManagerMap(Model):
    id = fields.IntField(pk=True)
    
    employee: fields.ForeignKeyNullableRelation["Employee"] = fields.ForeignKeyField(
        "models.Employee", related_name="manager_mapping", on_delete=fields.CASCADE
    )

    manager: fields.ForeignKeyNullableRelation["User"] = fields.ForeignKeyField(
        "models.User", related_name="employees_managed", on_delete=fields.CASCADE
    )