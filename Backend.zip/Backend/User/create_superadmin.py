from User.models import User
from utils import hash_password
from models import Employee
from fastapi import HTTPException

async def create_superadmin():
    email = "superadmin@gmail.com"
    password = "superadmin"
    
    existing_user = await User.get_or_none(email=email)
    
    if not existing_user:

        await User.create(
            email=email,
            hashed_password= hash_password(password),
            is_superadmin=True,
            is_hr=False,
            is_manager=False,
            is_employee=False,
            
        )
        print("Superadmin created.")
    else:
        print("Superadmin already exists.")

