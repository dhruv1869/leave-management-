from models import User
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

async def create_superuser():
    username = "superuser"
    email = "superuser@mail.com"
    password = "superuser"

    existing_user = await User.get_or_none(email=email)
    if not existing_user:
        await User.create(
            username=username,
            email=email,
            password=hash_password(password),
            role= "superuser"
        )
        print("Superuser created.")
    else:
        print("Superuser already exists.")
