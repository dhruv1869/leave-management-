from fastapi import FastAPI,Depends, HTTPException,Response,Request,UploadFile, File,Form,Query,WebSocket,WebSocketDisconnect
from contextlib import asynccontextmanager
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from tortoise.contrib.fastapi import register_tortoise
from models import Admin, TimeLog, Employee,Environment,MissReport
from pydantic import BaseModel
from pydantic_models import AdminIn, EmployeeIn,ConfigIn
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
import dotenv
from tortoise.exceptions import DoesNotExist
import os
from passlib.context import CryptContext
from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt
from routes.employee_routes import router as employee_router
from utils import authenticate_user, connected_clients,generate_frames,authenticate_employee,convert_to_local,format_duration
from fastapi.middleware.cors import CORSMiddleware
from utils import is_valid_rtsp_url,is_rtsp_stream_accessible,verify_password,create_token,authenticate_employee
import urllib.parse
from fastapi.responses import StreamingResponse
import time
from tortoise import Tortoise
from routes.model_routes import router as model_router
from pytz import timezone as pytz_timezone
from datetime import timezone as dt_timezone
from datetime import date
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import List,Dict
from pyngrok import ngrok
from LMS.views  import router as leave_routes
# from view import router
# from routes.admin import router as admin_routes
from User.views import router as user_routers
from User.create_superadmin import create_superadmin
from config import CONFIG_FILE

dotenv.load_dotenv()
CORS_ORIGIN = os.getenv("CORS_ORIGIN")
SECRET_KEY = os.getenv("SECRET_KEY")
ALGORITHM = os.getenv("ALGORITHM")
EXPIRE_TIME = os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES")

UNKNOWN_BASE_PATH = Path(__file__).resolve().parent.parent.parent / "unknowns"
STATIC_BASE_URL = "http://192.168.1.122:8000/static/unknowns"  # Change for deployment
from fastapi.staticfiles import StaticFiles

# public_url = ngrok.connect(8001)
# print("Public URL:", public_url)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

config_file = "tortoise_config_test.json" if os.getenv("TESTING") == "true" else "tortoise_config_test.json"



@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup logic
    await create_superadmin()
    yield
#     # Shutdown logic (optional)

app = FastAPI(lifespan=lifespan)

photos_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'photos'))
print(f"Photos directory: {photos_path}")
app.mount("/static/photos", StaticFiles(directory=photos_path), name="photos")
app.mount("/static", StaticFiles(directory=UNKNOWN_BASE_PATH.parent), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


print(config_file)

register_tortoise(
    app,
    config_file= CONFIG_FILE,
    generate_schemas=(False if os.getenv("TESTING") == "true" else True), #True,  # Auto-create tables
    add_exception_handlers=True,
)


# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=CORS_ORIGIN,  # list of allowed origins
#     allow_credentials=True,
#     allow_methods=["*"],  # allow all HTTP methods: POST, GET, OPTIONS etc.
#     allow_headers=["*"],  # allow all headers
# )

app.add_middleware(
    CORSMiddleware,
    allow_origins=['http://192.168.1.44:3000'],  # list of allowed origins
    allow_credentials=True,
    allow_methods=["*"],  # allow all HTTP methods: POST, GET, OPTIONS etc.
    allow_headers=["*"],  # allow all headers
)

# app.include_router(router)
app.include_router(employee_router)
app.include_router(model_router)
app.include_router(leave_routes)
app.include_router(user_routers)
# app.include_router(admin_routes)

@app.websocket("/ws/notifications")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connected_clients.append(websocket)
    try:
        while True:
            await websocket.receive_text()  # Keeps it alive
    except WebSocketDisconnect:
        connected_clients.remove(websocket)


@app.get("/admin")
async def get_admins(username = Depends(authenticate_user)):
    # if username != "superuser":#super user mangtuu tu atle comment karyu chee 
    #     raise HTTPException(status_code=403, detail="Forbidden")

    admins = await Admin.all().values("id", "username")
    return JSONResponse(content=admins)

# @app.post("/admin")
# async def create_admins(admin: AdminIn):
#     if not admin.username or not admin.password:
#         raise HTTPException(status_code=400, detail="Username and password are required")

#     existing_admin = await Admin.get_or_none(username=admin.username)
#     if existing_admin:
#         raise HTTPException(status_code=400, detail="Admin with this username already exists")

#     admin.password = pwd_context.hash(admin.password)
#     admin_obj = await Admin.create(**admin.model_dump())
#     return {"message": "Admin created", "username": admin_obj.username}

#token
# eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaHJ1diIsImV4cCI6MTc1NzU2NzMwNn0.Y2Ac-dnWoGvksa7IjMuHmhwWQoqtyxrjbXP0j2b2LdY
@app.post("/admin") 
async def create_admins(admin: AdminIn,username = Depends(authenticate_user)):
    if(username != "superuser"):#super user mangtuu tu atle comment karyu chee 
        raise HTTPException(status_code=403, detail="Forbidden")
    if not admin.username or not admin.password:
        raise HTTPException(status_code=400, detail="Username and password are required")
    existing_admin = await Admin.get_or_none(username=admin.username)
    if existing_admin:
        raise HTTPException(status_code=400, detail="Admin with this username already exists")
    admin.password = pwd_context.hash(admin.password)
    admin_obj = await Admin.create(**admin.model_dump())
    return {admin_obj}    

# @app.post("/admin")
# async def create_admins(admin: AdminIn):
#     # if(username != "superuser"):
#     #     raise HTTPException(status_code=403, detail="Forbidden")
#     if not admin.username or not admin.password:
#         raise HTTPException(status_code=400, detail="Username and password are required")
#     existing_admin = await Admin.get_or_none(username=admin.username)
#     if existing_admin:
#         raise HTTPException(status_code=400, detail="Admin with this username already exists")
#     admin.password = pwd_context.hash(admin.password)
#     admin_obj = await Admin.create(**admin.model_dump())
#     return {admin_obj}  


@app.delete("/admin/{admin_id}")
async def delete_admin(admin_id: int,username = Depends(authenticate_user)):
    # if(username != "superuser"):
    #     raise HTTPException(status_code=403, detail="Forbidden")
    admin = await Admin.get_or_none(id=admin_id)
    if admin.username == "superuser":
        raise HTTPException(status_code=403,detail="Can't Delete the Superuser")
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    await admin.delete()
    return {"message": "Admin deleted successfully"}

# @app.post("/login")
# async def login(response:Response,username:str = Form(...),password:str = Form(...)):
#     admin = await Admin.get_or_none(username=username)
#     if not admin or not verify_password(password, admin.password):
#         raise HTTPException(status_code=401, detail="Invalid credentials")
#     token = create_token({"sub": admin.username})
#     # response.set_cookie(
#     #     key="access_token",
#     #     value=token,
#     #     httponly=True,
#     #     secure=True,  
#     #     samesite=None,
#     #     max_age=3600  
#     # )
#     return {"access_token": token, "token_type": "bearer","username": admin.username}

@app.post("/logout")
async def logout(response: Response):
    response.delete_cookie("access_token")
    return {"message": "Logout successful"}


# @app.post("/admin/change-password")
# async def change_password(
#     username:str = Form(...),
#     old_password: str = Form(...),
#     new_password: str = Form(...),
    
# ):
#     # Fetch the employee
    
#     admin = await Admin.get_or_none(username=username)
#     print(admin)
#     if not admin:
#         raise HTTPException(status_code=404, detail="Admin not found")

#     # Verify old password
#     if not pwd_context.verify(old_password, admin.password):
#         raise HTTPException(status_code=401, detail="Incorrect old password")

#     # Prevent using the same password again
#     if pwd_context.verify(new_password, admin.password):
#         raise HTTPException(status_code=400, detail="New password must be different from the old password")

#     # Hash and update the password
#     admin.password = pwd_context.hash(new_password)
#     await admin.save()

#     return {"message": "Password changed successfully"}



@app.get("/getme")
async def authenticate_any_user(request: Request):
    try:
        username = await authenticate_user(request)
        return {"type": "admin", "username": username}
    except HTTPException:
        pass  # Try the next one

    try:
        empid = await authenticate_employee(request)
        emp = await Employee.get_or_none(empid=empid)
        return {"type": "employee", "empid": empid ,"name":emp.name}
    except HTTPException:
        pass

    raise HTTPException(status_code=401, detail="Authentication failed")


@app.get("/configure")
async def get_config(username = Depends(authenticate_user)):
    if username != "superuser":
        raise HTTPException(status_code=403, detail="Forbidden")
    envs_enter = await Environment.get_or_none(key="CAMERA_ENTER")
    envs_exit = await Environment.get_or_none(key="CAMERA_EXIT")
    if not envs_enter or not envs_exit:
        raise HTTPException(status_code=404, detail="Configuration not found")
    return {"camera_enter": envs_enter.value, "camera_exit": envs_exit.value}


@app.post("/configure")
async def set_config(cfg:ConfigIn, username = Depends(authenticate_user)):
    if username != "superuser":
        raise HTTPException(status_code=403, detail="Forbidden")
    if(not cfg.camera_enter or not cfg.camera_exit or not is_valid_rtsp_url(cfg.camera_enter) or not is_valid_rtsp_url(cfg.camera_exit)):
        raise HTTPException(status_code=400, detail="Invalid configuration values")
    
    if(is_rtsp_stream_accessible(cfg.camera_enter) == False):
        raise HTTPException(status_code=400, detail="Camera enter stream is not accessible")
    if(is_rtsp_stream_accessible(cfg.camera_exit) == False):
        raise HTTPException(status_code=400, detail="Camera exit stream is not accessible")
    envs = await Environment.get_or_none(key="CAMERA_ENTER")
    if envs:
        envs.value = cfg.camera_enter
        await envs.save()
    else:
        await Environment.create(key="CAMERA_ENTER", value=cfg.camera_enter)
    envs = await Environment.get_or_none(key="CAMERA_EXIT")
    if envs:
        envs.value = cfg.camera_exit
        await envs.save()
    else:
        await Environment.create(key="CAMERA_EXIT", value=cfg.camera_exit)
    return {"message": "Configuration updated successfully"}

@app.get("/stream")
async def stream_camera(request: Request):
    rtsp_url = request.query_params.get("url")
    print(f"Received RTSP URL: {rtsp_url}")
    if not rtsp_url:
        raise HTTPException(status_code=400, detail="Missing RTSP URL")

    decoded_url = urllib.parse.unquote(rtsp_url)

    # Validate the URL
    if not decoded_url.startswith("rtsp://"):
        raise HTTPException(status_code=400, detail="Invalid RTSP URL")

    # Use try-except to catch any OpenCV errors
    try:
        return StreamingResponse(
            generate_frames(decoded_url),
            media_type="multipart/x-mixed-replace; boundary=frame"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@app.get("/user-attendance")
async def get_user_attendance_summary(
    empid=Depends(authenticate_employee),
    start_date: date = Query(...),
    end_date: date = Query(...)
):  
    print(empid)
    employee = await Employee.get_or_none(empid=empid)
    if not employee:
        return {"error": "Employee not found"}

    result = []
    today = date.today()

    current = start_date
    while current <= end_date:
        next_day = current + timedelta(days=1)
        logs = await TimeLog.filter(
            employee=employee,
            timestamp__gte=datetime.combine(current, datetime.min.time()),
            timestamp__lt=datetime.combine(next_day, datetime.min.time())
        ).order_by("timestamp")

        entry_time = None
        exit_time = None
        in_time = 0
        corrupted = False
        inside = False
        last_in = None
        in_out_pairs = []

        for log in logs:
            if log.action == "IN":
                if inside:
                    corrupted = True  # Two consecutive INs
                else:
                    last_in = log.timestamp
                    inside = True
                    if not entry_time:
                        entry_time = log.timestamp
            elif log.action == "OUT":
                if inside and last_in:
                    delta = (log.timestamp - last_in).total_seconds()
                    in_time += delta
                    in_out_pairs.append((last_in, log.timestamp))
                    exit_time = log.timestamp
                    inside = False
                    last_in = None
                else:
                    corrupted = True  # OUT without prior IN

        # Handle unmatched IN (still inside)
        if inside:
            if current == today:
                corrupted = False  # Allow it for today
                exit_time = None  # Don't set lastExit if still inside
            else:
                corrupted = True

        total_span = 0
        total_out_time = 0
        if entry_time and exit_time and entry_time < exit_time:
            total_span = (exit_time - entry_time).total_seconds()
            total_out_time = total_span - in_time
         # Python 3.9+
# Or use `pytz` if you're on Python < 3.9

        
        result.append({
            "date": current.strftime("%Y-%m-%d"),
            "firstEntry": convert_to_local(entry_time).strftime("%I:%M %p") if entry_time else "-",
            "lastExit": convert_to_local(exit_time).strftime("%I:%M %p") if exit_time else "-",  # will be "-" if still inside today
            "totalInTime": format_duration(int(in_time)) if entry_time and exit_time else "-",
            "totalOutTime": format_duration(int(total_out_time)) if entry_time and exit_time else "-",
            "status": "Present" if entry_time and not corrupted else ("Absent" if not entry_time else "Corrupted")
        })

        current += timedelta(days=1)

    return result
import pytz
from datetime import datetime, timezone

LOCAL_TIMEZONE = pytz.timezone("Asia/Kolkata")

@app.post("/attendance-miss-report")
async def create_miss_report(request: Request, empid=Depends(authenticate_employee)):
    data = await request.json()

    try:
        date = data.get("date")  # Expected format: "YYYY-MM-DD"
        time = data.get("time")  # Expected format: "HH:MM"
        action = data.get("type")  # "entry" or "exit"
        reason = data.get("reason")

        if not date or not time or not action:
            raise HTTPException(status_code=400, detail="Missing required fields: date, time, or type")

        if action == 'entry':
            action = "IN"
        elif action == 'exit':
            action = "OUT"
        else:
            raise HTTPException(status_code=400, detail="Invalid action type")

        # Combine date and time as naive datetime
        try:
            timestamp_naive = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date or time format")

        # Localize naive datetime to local timezone (Asia/Kolkata)
        local_dt = LOCAL_TIMEZONE.localize(timestamp_naive)

        # Convert local datetime to UTC
        timestamp_utc = local_dt.astimezone(timezone.utc)

        # Fetch the employee
        employee = await Employee.get(empid=empid)

        # Create the missed attendance report with UTC timestamp
        report = await MissReport.create(
            timestamp=timestamp_utc,
            action=action,
            employee=employee,
            reason=reason,
            status="pending"
        )

        return {
            "message": "Missed attendance report submitted successfully",
            "report_id": report.id
        }

    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Employee not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
@app.get("/attendance-miss-report")
async def get_miss_reports(username=Depends(authenticate_user)):
    try:
        
        reports = await MissReport.filter(status="pending").select_related('employee').order_by("-timestamp").all()

        return [
        {
            "id": report.id,
            "employeeId": report.employee.empid,
            "employeeName": report.employee.name,
            "date": convert_to_local(report.timestamp).date().isoformat(),    # e.g. "2025-06-05"
            "time": convert_to_local(report.timestamp).time().strftime("%H:%M"),  # e.g. "14:30:00"
            "type": report.action,
            "reason": report.reason,
        }
        for report in reports
        ]

    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Employee not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.post("/accept-report/{id}")
async def accept_report(id: int, username=Depends(authenticate_user)):
    if not id:
        raise HTTPException(status_code=400, detail="Report ID is required")

    try:
        report = await MissReport.get(id=id).prefetch_related("employee")
    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Missed report not found")

    try:
        # Ensure timestamp is timezone-aware
        if report.timestamp.tzinfo is None:
            india_tz = pytz_timezone("Asia/Kolkata")
            local_time = india_tz.localize(report.timestamp)
            report.timestamp = local_time.astimezone(dt_timezone.utc)
        else:
            report.timestamp = report.timestamp.astimezone(dt_timezone.utc)

        # Create TimeLog
        timelog = await TimeLog.create(
            timestamp=report.timestamp,
            action=report.action,
            employee=report.employee
        )

        # Update report status instead of deleting
        report.status = "accepted"
        await report.save()

        return {
            "message": "Report accepted and time log created",
            "timelog_id": timelog.id
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@app.post("/reject-report/{id}")
async def reject_report(id: int, username=Depends(authenticate_user)):
    if not id:
        raise HTTPException(status_code=400, detail="Report ID is required")

    try:
        report = await MissReport.get(id=id).prefetch_related("employee")
    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Missed report not found")

    try:
        # Just update status
        report.status = "rejected"
        await report.save()

        return {
            "message": "Report rejected",
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

from fastapi import Query
from typing import Literal

@app.get("/previous-reports")
async def get_reports(
    
    username=Depends(authenticate_user)
):
    try:
        reports = await MissReport.filter().prefetch_related("employee")
        return [
            {
                "id": r.id,
                "empid": r.employee.empid,
                "name": r.employee.name,
                "timestamp": r.timestamp.isoformat(),
                "action": r.action,
                "status": r.status,
                "reason":r.reason
            }
            for r in reports
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


from fastapi import APIRouter, Depends, HTTPException
from models import MissReport, Employee  # Adjust import paths as needed
from tortoise.exceptions import DoesNotExist


@app.get("/employee-reports")
async def get_reports_by_employee(empid= Depends(authenticate_employee)):
    try:
        employee = await Employee.get(empid=empid)
    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Employee not found")

    reports = await MissReport.filter(employee=employee).order_by("-timestamp").all()

    return {
        "empid": empid,
        "employee_name": employee.name,
        "total_reports": len(reports),
        "reports": [
            {
                "id": report.id,
                "timestamp": report.timestamp.isoformat(),
                "action": report.action,
                "status": report.status,
                "reason": report.reason,
            }
            for report in reports
        ]
    }


@app.get("/unknowns/", response_model=List[Dict[str, str]])
def get_unknowns_near_time(
    username=Depends(authenticate_user),
    type: str = Query(..., regex="^(enter|exit)$"),
    timestamp: str = Query(..., description="Format: YYYY-MM-DD_HH-MM-SS")
):
    try:
        query_time = datetime.strptime(timestamp, "%Y-%m-%d_%H-%M-%S")
    except ValueError:
        return [{"error": "Invalid timestamp format. Use YYYY-MM-DD_HH-MM-SS"}]

    matched = []

    for folder in UNKNOWN_BASE_PATH.glob(f"{type}_*"):
        try:
            folder_time_str = folder.name.replace(f"{type}_", "")
            folder_time = datetime.strptime(folder_time_str, "%Y-%m-%d_%H-%M-%S")
            delta = abs((folder_time - query_time).total_seconds())
            if delta <= 5 * 60:
                img_path = folder / f"{type}_best.jpg"
                if img_path.exists():
                    matched.append({
                        "url": f"{STATIC_BASE_URL}/{folder.name}/{type}_best.jpg",
                        "timestamp": folder_time.strftime("%Y-%m-%d_%H-%M-%S")
                    })
        except Exception:
            continue

    return matched