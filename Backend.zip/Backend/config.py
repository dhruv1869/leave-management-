import os
from dotenv import load_dotenv

load_dotenv()

TESTING = os.getenv("TESTING") == "true"
CONFIG_FILE = "tortoise_config_test.json" if TESTING else "tortoise_config.json"




TORTOISE_ORM = {
  "connections": {
    "default": "mysql://root:root@localhost:3306/leave_mangment"
  },
  "apps": {
    "models": {
      "models": ["models", "aerich.models", "LMS.models", "User.models"],
      "default_connection": "default"
    }
  }
}