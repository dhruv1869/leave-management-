# Create leave with foreign key
from fastapi import APIRouter, UploadFile, File, HTTPException,Request, Depends
from LMS.models import LeaveRequest, LeaveBalance
from models import Employee
from models import Admin
from tortoise.exceptions import DoesNotExist
from pydantic import BaseModel
from datetime import date
from typing import Optional, List
from fastapi import Form
from fastapi.responses import JSONResponse
import os
from datetime import datetime, date
from main import authenticate_employee, authenticate_user
from decimal import Decimal 
from User.models import User, EmployeeManagerMap
from User.views import get_current_user
from tortoise.transactions import in_transaction
from datetime import timedelta

router = APIRouter(
    prefix="/lms",
    tags=["leave"]
)

class EmployeeOut(BaseModel):
    id: int
    name: str
    empid: str
    
    
    model_config = {
        "from_attributes": True  # ✅ For Pydantic v2
    }

class LeaveBalanceOut(BaseModel):
    sick_leave: Decimal
    casual_leave: Decimal
    optional_leave: Decimal
    earned_leave: Decimal

    total_sick_leave: Decimal
    total_casual_leave: Decimal
    total_optional_leave: Decimal
    total_earned_leave: Decimal

    class Config:
        orm_mode = True

class LeaveRequestIn(BaseModel):
    employee_id: int                 # corresponds to ForeignKey field
    leave_type: str                 # maps to leave_type
    start_date: date
    end_date: date
    reason: Optional[str] = None
    is_half_day: Optional[bool] = False

class LeaveRequestOut(BaseModel):
    message: str
    employee: EmployeeOut
    status: str

    model_config = {
        "from_attributes": True
    }

class LeaveRequestDetailOut(BaseModel):
    id: int
    employee: EmployeeOut
    leave_type: str
    start_date: date
    end_date: date
    total_days: float
    leave_without_pay: float
    apply_date: datetime
    reason: Optional[str]
    half_day_start_type: Optional[str]
    half_day_end_type: Optional[str]
    attachment: Optional[str]
    status: str
    approve_date: Optional[date]
    approve_comment: Optional[str]
    reject_date: Optional[date]
    reject_comment: Optional[str]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True

class LeaveDataOut(BaseModel):
    leaves: List[LeaveRequestDetailOut]
    balance: Optional[LeaveBalanceOut]

def calculate_leave_with_weekend_sandwich(start_date, end_date, half_start, half_end, weekends=[5, 6]):

    is_sandwich_apply= True

    if (start_date.weekday() == 4 and half_start is not None) or (end_date.weekday()== 0 and half_end is not None):
        is_sandwich_apply = False
    delta = end_date - start_date
    total_days = 0
    sandwich_days = 0

    for i in range(delta.days + 1):
        current = start_date + timedelta(days=i)
        
        if current.weekday() in weekends:
            # Count weekend only if not at the edge
            if i != 0 and i != delta.days and is_sandwich_apply:
                total_days += 1
                sandwich_days += 1
        else:
            total_days += 1

    if not is_sandwich_apply:
        total_days = total_days -sandwich_days
        sandwich_days = 0

    return total_days, sandwich_days


# @router.post("/apply_leave/", response_model=LeaveRequestOut)
# async def create_leave(
#     request: Request,
#     leave_type: str = Form(...),
#     start_date: date = Form(...),
#     end_date: date = Form(...),
#     reason: Optional[str] = Form(None),
#     is_half_day: Optional[bool] = Form(False),
#     half_day_type: Optional[str] = Form(None),
#     attachment: Optional[UploadFile] = File(None),
# ):  
    
#     try:
#         empid = await authenticate_employee(request)
#         employee = await Employee.get_or_none(empid=empid)
#         # employee = await Employee.get(id= employee_id)
#     except DoesNotExist:
#         raise HTTPException(status_code=404, detail="Employee not found")
    
#     VALID_LEAVE_TYPES = {"sick", "optional", "casual", "earned"}

#     if leave_type not in VALID_LEAVE_TYPES:
#         raise HTTPException(status_code=400, detail=f"Invalid leave type : {leave_type}")
    
#     if is_half_day==True and not half_day_type:
#         raise HTTPException(status_code=400, detail="half_day_type is required for half-day leave")
    
#     if half_day_type==True and half_day_type.lower() not in {"first", "second"}:
#         raise HTTPException(status_code=400, detail="half_day_type must be 'first' or 'second'")
#     try:
        
#         if is_half_day:
#             total_days = 0.5
#         else:
#             total_days = (end_date - start_date).days + 1

#         file_path = None
#         if attachment:
#             upload_dir = "uploads"
#             os.makedirs(upload_dir, exist_ok=True)  

#             file_path = os.path.join(upload_dir, attachment.filename)
#             file_path = f"uploads/{attachment.filename}"
#             with open(file_path, "wb") as f:
#                 f.write(await attachment.read())

#         leave = await LeaveRequest.create(
#             employee=employee,
#             leave_type=leave_type,
#             start_date=start_date,
#             end_date=end_date,
#             total_days=total_days,
#             reason=reason,
#             is_half_day=is_half_day,
#             half_day_type=half_day_type,
#             attachment=file_path,
#         )

#         return {"message": "Leave request submitted successfully",
#                 "employee": EmployeeOut.from_orm(employee),
#                 "status": "Success"}
    
#     except Exception as e:
#          raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")


#apply_leave
@router.post("/apply_leave", response_model=LeaveRequestOut)
async def create_leave(
    request: Request,
    leave_type: str = Form(...),
    start_date: date = Form(...),
    end_date: date = Form(...),
    reason: Optional[str] = Form(None),
    half_day_start_type: Optional[str]= Form(None),
    half_day_end_type: Optional[str]= Form(None),
    attachment: Optional[UploadFile] = File(None),
    current_user: User= Depends(get_current_user)
):  
    
    try:    
        
        employee = await current_user.employee
        if not employee:
            raise HTTPException(status_code=403, detail="User is not linked to an employee.")
        # empid = await authenticate_employee(request)
        # employee = await Employee.get_or_none(user=current_user)
        # employee = await Employee.get(id= employee_id)
    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    
    employee_leave_balance = await LeaveBalance.get_or_none(employee = employee)

    if not employee_leave_balance:
        raise HTTPException (status_code= 403, detail="Leave Balance not set. Contact HR.")
    
    VALID_LEAVE_TYPES = {"sick", "optional", "casual", "earned"}

    if leave_type not in VALID_LEAVE_TYPES:
        raise HTTPException(status_code=400, detail=f"Invalid leave type : {leave_type}")

    if start_date > end_date:
        raise HTTPException(status_code=400, detail="Start date cannot be after end date")
    
    current_date = date.today()
    if current_date > start_date or current_date > end_date:
        raise HTTPException(status_code=400, detail= "Leave date has already passed.")
    
    if half_day_start_type:
        if half_day_start_type.lower() not in {"first", "second"}:
            raise HTTPException(
                status_code=400,
                detail="half_day_start_type must be either 'first' or 'second'"
            )

    if half_day_end_type:
        if half_day_end_type.lower() not in {"first", "second"}:
            raise HTTPException(
                status_code=400,
                detail="half_day_end_type must be either 'first' or 'second'"
            )
        
    is_already_applied = await LeaveRequest.filter(
        employee_id = employee.id,
        status__in = ['pending', 'approved'],
        start_date__lte = end_date,
        end_date__gte = start_date).exists()

    if is_already_applied:
        raise HTTPException (status_code=400, detail="Duplicate leave: Dates already applied.")
    
    try:  
        if start_date == end_date:
            if half_day_start_type or half_day_end_type:
                sandwich_days = 0
                total_days = 0.5
            else:
                sandwich_days =0
                total_days = 1.0
            
           
        else:
            total_days, sandwich_days = calculate_leave_with_weekend_sandwich(start_date, end_date, half_day_start_type, half_day_end_type)
            # total_days = (end_date - start_date).days + 1
            if half_day_start_type:
                if half_day_start_type.lower() not in {"first", "second"}:
                    raise HTTPException(status_code=400, detail="half_day_start_type must be 'first' or 'second'")
                total_days -= 0.5
            if half_day_end_type:
                if half_day_end_type.lower() not in {"first", "second"}:
                    raise HTTPException(status_code=400, detail="half_day_end_type must be 'first' or 'second'")
                total_days -= 0.5

        file_path = None
        if attachment:
            upload_dir = "uploads"
            os.makedirs(upload_dir, exist_ok=True)  

            file_path = os.path.join(upload_dir, attachment.filename)
            file_path = f"uploads/{attachment.filename}"
            with open(file_path, "wb") as f:
                f.write(await attachment.read())
                
        leave = await LeaveRequest.create(
            employee=employee,
            leave_type=leave_type,
            start_date=start_date,
            end_date=end_date,
            total_days=total_days,
            reason=reason,
            half_day_start_type = half_day_start_type,
            half_day_end_type = half_day_end_type,
            attachment=file_path,
        )

        return {"message": f"Leave request for {total_days} days submitted successfully, including {sandwich_days} sandwich weekend day(s).",
                "employee": EmployeeOut.from_orm(employee),
                "status": "Success"}
    
    except HTTPException:
        raise

    except Exception as e:
         raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")

#update leave reuest
@router.patch("/leave/{leave_id}", response_model=LeaveRequestDetailOut)
async def update_leave_request(
    request: Request,
    leave_id: int,
    leave_type: Optional[str] = Form(None),
    start_date: Optional[date] = Form(None),
    end_date: Optional[date] = Form(None),
    reason: Optional[str] = Form(None),
    half_day_start_type: Optional[str] = Form(None),
    half_day_end_type: Optional[str] = Form(None),
    attachment: Optional[UploadFile] = File(None),
    current_user: User= Depends(get_current_user)
):
    # empid = await authenticate_employee(request)
    employee = await current_user.employee

    if not employee:
        raise HTTPException(status_code=404, detail="Employee not found")

    VALID_LEAVE_TYPES = {"sick", "optional", "casual", "earned"}

    try:
        leave = await LeaveRequest.get(id=leave_id).prefetch_related('employee')

        if leave.status in ["approved", "rejected"]:
            raise HTTPException(status_code=400, detail=f"Cannot update leave once it is {leave.status}")

        # Validate and update fields
        if leave_type:
            if leave_type.lower() not in VALID_LEAVE_TYPES:
                raise HTTPException(status_code=400, detail=f"Invalid leave type: {leave_type}")
            leave.leave_type = leave_type.lower()

        if start_date:
            leave.start_date = start_date
        if end_date:
            leave.end_date = end_date
        if reason is not None:
            leave.reason = reason
        if half_day_start_type and half_day_start_type.lower() not in {"first", "second"}:
            raise HTTPException(status_code=400, detail="half_day_start_type must be either 'first' or 'second'")
        if half_day_end_type and half_day_end_type.lower() not in {"first", "second"}:
            raise HTTPException(status_code=400, detail="half_day_end_type must be either 'first' or 'second'")

        leave.half_day_start_type = half_day_start_type
        leave.half_day_end_type = half_day_end_type

        if leave.start_date and leave.end_date:
            if leave.start_date > leave.end_date:
                raise HTTPException(status_code=400, detail="Start date cannot be after end date")

            if leave.start_date == leave.end_date:
                if half_day_start_type or half_day_end_type:
                    leave.total_days = 0.5
                else:
                    leave.total_days = 1.0

            else:
                total_days = (leave.end_date - leave.start_date).days + 1
                if half_day_start_type:
                    total_days -= 0.5
                if half_day_end_type:
                    total_days -= 0.5
                leave.total_days = total_days

        # Handle attachment update
        if attachment:
            upload_dir = "uploads"
            os.makedirs(upload_dir, exist_ok=True)
            file_path = os.path.join(upload_dir, attachment.filename)

            with open(file_path, "wb") as f:
                f.write(await attachment.read())

            leave.attachment = file_path

        await leave.save()
        return leave

    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Leave request not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
#get my leaves
@router.get("/my-leaves", response_model=LeaveDataOut)
async def get_my_leaves(request: Request, current_user: User= Depends(get_current_user)):
    try:
        
        employee = await current_user.employee
        # Check if the employee exists (optional but safe)
        # employee = await Employee.get(id=employee_id)
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")
        # Get all leave records for the employee
        leaves = await LeaveRequest.filter(employee_id=employee.id).order_by("-start_date").prefetch_related("employee")
        balance = await LeaveBalance.get_or_none(employee=employee)
        
        return {
            "leaves": leaves,
            "balance": balance
        }
    
    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
    
#get leave by id
@router.get("/leave/{leave_id}", response_model=LeaveRequestDetailOut)
async def get_leave(leave_id: int):
    try:
        leave = await LeaveRequest.get(id=leave_id).prefetch_related("employee")
        return leave
    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Leave request not found")

#get all the leaves
@router.get("/all_leaves/", response_model= List[LeaveRequestDetailOut])
async def get_all_leave(current_user: User= Depends(get_current_user)):
    try:
        if not (current_user.is_hr or current_user.is_superadmin or current_user.is_manager):
            raise HTTPException(status_code=403, detail="Not authorised to Get the leaves")
        
        if current_user.is_manager:
            
            employee_ids = await EmployeeManagerMap.filter(
                manager_id=current_user.id
            ).values_list("employee_id", flat=True)

            # Step 2: Get leaves for those employees
            leaves = await LeaveRequest.filter(
                employee_id__in=employee_ids
            ).prefetch_related("employee")
        
        else:
            leaves = await LeaveRequest.all().prefetch_related("employee")

        return leaves

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
    
#delete leave by id   
@router.delete("/leave/{leave_id}", response_model= LeaveRequestOut)
async def delete_leave_request(request: Request, leave_id: int, current_user: User =Depends(get_current_user)):
    try:
        async with in_transaction():
            employee = await current_user.employee
            if not employee:
                raise HTTPException(status_code=404, detail="Employee not found")
        
            leave = await LeaveRequest.get(id=leave_id)
            if leave.employee_id!= employee.id:
                raise HTTPException(status_code=403, detail="Not authorized to delete this leave")
        
            if leave.status in ["approved", "rejected"]:
                raise HTTPException(status_code=400, detail=f"Cannot delete a {leave.status} leave request")

            await leave.delete()

        return {"message": "Leave request deleted  successfully",
                "employee": EmployeeOut.model_validate(employee),
                "status": "Success"}

    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Leave request not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

#Add leave-balance
@router.patch("/admin/leave_balance/{employee_id}")
async def update_leave_balance(
    request: Request,
    employee_id: str,
    sick_leave: Optional[float] = Form(None),
    casual_leave: Optional[float] = Form(None),
    optional_leave: Optional[float] = Form(None),
    earned_leave: Optional[float] = Form(None),
    current_user: User= Depends(get_current_user)
):
    try:
        # Step 1: Authenticate admin and get admin Employee object
        if not(current_user.is_superadmin or current_user.is_hr):
            raise HTTPException(status_code=403, detail="You don't have permission to add leave balance.")
        

        employee = await Employee.get_or_none(empid = employee_id)
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")

        balance, created = await LeaveBalance.get_or_create(employee=employee)

        # Update leave balances
        if sick_leave is not None:
            balance.sick_leave += sick_leave
            balance.total_sick_leave += sick_leave
        if casual_leave is not None:
            balance.casual_leave += casual_leave
            balance.total_casual_leave += casual_leave
        if optional_leave is not None:
            balance.optional_leave += optional_leave
            balance.total_optional_leave += optional_leave
        if earned_leave is not None:
            balance.earned_leave += earned_leave
            balance.total_earned_leave += earned_leave

        # Set audit fields
        if created:
            balance.updated_by = current_user
        balance.updated_by = current_user

        await balance.save()

        return {
            "message": "Leave balance created" if created else "Leave balance updated successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")

#update leave status
@router.patch("/admin/leave_status/{leave_id}")
async def update_leave_status(
    request: Request,
    leave_id: int,
    status: str = Form(...), # approved or rejected
    comment: str = Form(None) ,
    current_user:  User = Depends(get_current_user)
):
    try:

        if not(current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
            raise HTTPException(status_code=403, detail="You don't have permission to approve/reject the leave")
        
        leave = await LeaveRequest.get_or_none(id=leave_id).prefetch_related("employee")
        if not leave:
            raise HTTPException(status_code=404, detail="Leave request not found")
        
        employee = leave.employee
        if current_user.is_manager:
            is_managed = await EmployeeManagerMap.filter(
                manager=current_user,
                employee=employee
            ).exists()

            if not is_managed:
                raise HTTPException(status_code=403, detail="You don't have permission to approve/reject current employee leave")
                
        if status == "approved" and leave.status == "approved":
            raise HTTPException(status_code=400, detail=f"Leave cannot be approved as it is already {leave.status}")

        if status == "rejected" and leave.status == "rejected":
            raise HTTPException(status_code=400, detail="Leave is already rejected")
        
        # if leave.status in ["approved", "rejected"]:
        #     raise HTTPException(status_code=400, detail=f"Leave already {leave.status}")

        if status not in {"approved", "rejected"}:
            raise HTTPException(status_code=400, detail="Status must be 'approved' or 'rejected'")

        # Optional: Deduct from balance if approving
        if status == "approved":
            balance = await LeaveBalance.get_or_none(employee=leave.employee_id)
            if not balance:
                raise HTTPException(status_code=404, detail="Leave balance not found")
            
            leave_days = float(leave.total_days)
            remaining = leave_days
            deducted = {
                "sick": 0.0,
                "casual": 0.0,
                "earned": 0.0,
                "optional": 0.0,
            }

            # Priority-wise deduction logic
            def deduct(leave_type_field, amount):
                current = float(getattr(balance, leave_type_field))
                if current <= 0:
                    return 0.0
                to_deduct = min(current, amount)
                setattr(balance, leave_type_field, round(current - to_deduct, 1))
                return to_deduct

            # Deduct from primary type
            if leave.leave_type == "optional":
                # Only allow optional leave if explicitly requested
                if balance.optional_leave < remaining:
                    raise HTTPException(status_code=400, detail="Insufficient optional leave balance")
                deducted["optional"] = deduct("optional_leave", remaining)
                remaining -= deducted["optional"]
            
            else:
                # Step 1: Deduct from primary
                primary_type = leave.leave_type
                deducted[leave.leave_type] = deduct(f"{leave.leave_type}_leave", remaining)
                remaining -= deducted[leave.leave_type]
                

                # Step 2: Then from casual
                if remaining > 0 and primary_type != 'casual':
                    deducted["casual"] = deduct("casual_leave", remaining)
                    remaining -= deducted["casual"]
                    

                # Step 3: Then from earned
                if remaining > 0 and primary_type != 'earned':
                    deducted["earned"] = deduct("earned_leave", remaining)
                    remaining -= deducted["earned"]
                    

            leave.sick_deducted = Decimal(str(deducted["sick"]))
            leave.casual_deducted = Decimal(str(deducted["casual"]))
            leave.earned_deducted = Decimal(str(deducted["earned"]))
            leave.optional_deducted = Decimal(str(deducted["optional"]))
            # What's left becomes unpaid
            leave.leave_without_pay = round(remaining, 1)
            leave.status = "approved"
            leave.approve_date = date.today()
            leave.approve_comment = comment
            leave.action_by = current_user

            await balance.save()
            await leave.save()

            return {
                "message": "Leave approved",
                "leave_without_pay": leave.leave_without_pay,
                "deductions": deducted,

            }

        elif status == "rejected":
            if leave.status == "approved":
                # Reverse deductions
                balance = await LeaveBalance.get_or_none(employee=leave.employee_id)
                if not balance:
                    raise HTTPException(status_code=404, detail="Leave balance not found")

                # Restore exact amounts
                def restore(leave_type_field, amount):
                    current = getattr(balance, leave_type_field)
                    setattr(balance, leave_type_field, round(current + float(str(amount)), 1))

                restore("sick_leave", leave.sick_deducted)
                restore("casual_leave", leave.casual_deducted)
                restore("earned_leave", leave.earned_deducted)
                restore("optional_leave", leave.optional_deducted)

                await balance.save()
                leave.sick_deducted = 0
                leave.casual_deducted = 0
                leave.earned_deducted = 0
                leave.optional_deducted = 0
                leave.leave_without_pay = 0

                # Finalize rejection
                leave.status = "rejected"
                leave.reject_date = date.today()
                leave.reject_comment = comment
                leave.action_by = current_user
                await leave.save()

                return {"message": "Leave rejected and balance restored (if previously approved)"}

    except HTTPException:
        raise
    
    except Exception as e:
         raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
