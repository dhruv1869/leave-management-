from tortoise.models import Model
from tortoise import fields


class LeaveRequest(Model):
    id = fields.IntField(pk=True)
    employee = fields.ForeignKeyField(
        "models.Employee", related_name="leaves", on_delete=fields.CASCADE
    )
    
    leave_type = fields.CharField(max_length=20)
    apply_date = fields.DatetimeField(auto_now_add=True)
    start_date = fields.DateField()
    end_date = fields.DateField()
    total_days = fields.DecimalField(max_digits=4, decimal_places=1, default=0)
    leave_without_pay = fields.DecimalField(max_digits=4, decimal_places=1, default=0)
    reason = fields.TextField(null=True)
    attachment = fields.CharField(max_length=255, null=True)
    status = fields.CharField(max_length=20, default="pending")  # pending, approved, rejected
    half_day_start_type = fields.CharField(max_length=20, null=True)
    half_day_end_type = fields.CharField(max_length=10, null=True)
    approve_date = fields.DateField(null=True)
    approve_comment = fields.TextField(null=True)
    reject_date = fields.DateField(null=True)
    reject_comment = fields.TextField(null=True)
    action_by = fields.ForeignKeyField(
        "models.User", related_name= "leave_actions", null=True
    )
    casual_deducted = fields.DecimalField(max_digits=4, decimal_places=1, default=0)
    earned_deducted = fields.DecimalField(max_digits=4, decimal_places=1, default=0)
    sick_deducted = fields.DecimalField(max_digits=4, decimal_places=1, default=0)
    optional_deducted = fields.DecimalField(max_digits=4, decimal_places=1, default=0)
    
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)
    
class LeaveBalance(Model):
    id = fields.IntField(pk=True)
    employee = fields.ForeignKeyField(
        "models.Employee", related_name="leave_balances", on_delete=fields.CASCADE
    )

    sick_leave = fields.FloatField(default=0)
    casual_leave = fields.FloatField(default=0)
    optional_leave = fields.FloatField(default=0)
    earned_leave = fields.FloatField(default=0)
    
    total_sick_leave = fields.FloatField(default = 0)
    total_casual_leave = fields.FloatField(default = 0)
    total_optional_leave = fields.FloatField(default = 0)
    total_earned_leave = fields.FloatField(default = 0)

    updated_by = fields.ForeignKeyField(
        "models.User", related_name= "leave_updated_by", null=True
    )
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)    