from tortoise import Tortoise, run_async

async def create_tables():
    await Tortoise.init(config_file="tortoise_config_test.json")
    await Tortoise.generate_schemas()
    await Tortoise.close_connections()
    print("Tables created in MySQL!")

run_async(create_tables())
