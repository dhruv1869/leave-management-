# routers/employee.py
# import sys
# sys.path.append(os.path.abspath(".."))
from models import Employee,TimeLog  
from fastapi import APIRouter, Depends, HTTPException,UploadFile,File,Form,Request,Query,Response
from pydantic_models import EmployeeIn
from utils import authenticate_user,verify_password,create_token,authenticate_employee,connected_clients
import shutil
import dotenv
import os
from uuid import uuid4
from fastapi.responses import JSONResponse
from tortoise.exceptions import DoesNotExist
from datetime import datetime, timedelta, date
from tortoise.expressions import Q
from zoneinfo import ZoneInfo 
import random
import string
from passlib.context import CryptContext
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
import time
import asyncio
from User.views import get_current_user
from User.models import EmployeeManagerMap
from typing import Optional, List
from fastapi import APIRouter, Form, UploadFile, File, Depends, HTTPException
from uuid import uuid4
import os
from tortoise.transactions import in_transaction
from typing import Optional
from fastapi import Form
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

from User.models import User
from pydantic_models import BaseModel
from utils import hash_password
import pytz


LOCAL_TIMEZONE = pytz.timezone("Asia/Kolkata")
print(datetime.now(LOCAL_TIMEZONE))
entry_buffer = {}
dotenv.load_dotenv()
UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER") if os.getenv("TESTING") == "false" else os.getenv("TESTING_UPLOAD_FOLDER")
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/jpg", "image/webp"}


LOCAL_TIMEZONE = ZoneInfo("Asia/Kolkata")  # replace with yours

def convert_to_local(dt):
     # treat naive as UTC
    return dt.astimezone(LOCAL_TIMEZONE)
router = APIRouter(
    prefix="/employee",
    tags=["Employees"]
)
def format_duration(seconds: int):
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    return f"{hours}h {minutes}m"

photo_directory = os.path.basename(UPLOAD_FOLDER)
PHOTOS_BASE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..', photo_directory))
print(f"Photos base path: {PHOTOS_BASE_PATH}")

from fastapi import APIRouter, Request, HTTPException, Depends
import os
MODEL_PATH = os.getenv("MODEL_PATH")
ENV_PATH = os.getenv("ENV_PATH")
EMBD_PATH = os.getenv("EMBD_PATH")
PHOTOS_PATH = os.getenv("PHOTOS_PATH")
EMBD_UPDATE_PATH = os.getenv("EMBD_UPDATE_PATH")

import subprocess


class EmployeeCreate(BaseModel):
    username: str
    email: str
    password: str
    empid: str
    employee_name: str

class EmployeeOut(BaseModel):
    id : int
    empid: str
    name : str
    
    class Config:
        orm_mode = True

class EmployeeManagerMapOut(BaseModel):
    employee: EmployeeOut

    class Config:
        orm_mode = True

class UserOut(BaseModel):
    id : int
    email: str
    is_superadmin: bool
    is_hr: bool
    is_manager: bool
    is_employee: bool

    employee: Optional[EmployeeOut] = None
    employees_managed: List[EmployeeManagerMapOut] = []
    class Config:
        orm_mode = True



async def update_embedding(empid: str):
    try:
        venv_python = os.path.abspath(ENV_PATH)  # path to your Python binary
        update_script = os.path.abspath(EMBD_UPDATE_PATH)  # script we made earlier

        process = subprocess.Popen(
            [venv_python, update_script, empid],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        logs = []
        while True:
            line = process.stdout.readline()
            if line == "" and process.poll() is not None:
                break
            if line:
                logs.append(line.strip())

        stderr_output = process.stderr.read()
        if process.returncode != 0:
            raise HTTPException(
                status_code=500,
                detail=f"Embedding update failed for {empid}:\n{stderr_output.strip()}"
            )
        print(logs)
        return {
            "status": "success",
            "message": f"Embedding updated for employee {empid}.",
            "logs": logs
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"An unexpected error occurred while updating embedding for {empid}: {str(e)}"
        )

#get_employee by id
@router.get("/{id}")
async def get_employee(id: str, request: Request, current_user: User=Depends(get_current_user)):
    try:
        if not(current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
            raise HTTPException(status_code=403, detail="You don't have permission to get employee detils.")
        emp_obj = await Employee.get_or_none(empid=id)
        employee = await Employee.get_or_none(empid=id).values("id","empid", "name", "email")

        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")

        # Check manager permission
        if current_user.is_manager:
            
            is_managed = await EmployeeManagerMap.filter(
                manager=current_user,
                employee=emp_obj
            ).exists()

            if not is_managed:
                raise HTTPException(status_code=403, detail="You don't have access to this employee's details.")

        emp_id = str(employee["empid"])
        photo_dir = os.path.join(PHOTOS_BASE_PATH, emp_id)

        photo_urls = []
        if os.path.isdir(photo_dir):
            files = os.listdir(photo_dir)
            image_files = [f for f in files if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
            for filename in image_files:
                url = request.url_for("photos", path=f"{emp_id}/{filename}")
                photo_urls.append(url._url)

        employee["photos"] = photo_urls  # Send all photos as list
        return {"employee": employee}
    
    except HTTPException:
        raise  
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


#get_all_employees
@router.get("/")
async def get_employees(request: Request, current_user: User=Depends(get_current_user)):

    try:
        if not(current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
            raise HTTPException(status_code=403, detail="You don't have permission to get employees detils.")
        
        # If manager, get only employees they manage
        if current_user.is_manager:
        
            # Get employee IDs managed by the current user
            managed_mappings = await EmployeeManagerMap.filter(manager=current_user).prefetch_related("employee")
            employee_ids = [mapping.employee_id for mapping in managed_mappings]
            
            employees = await Employee.filter(id__in=employee_ids).values("id", "empid", "name", "email")
        else:
            # For HR and superadmin, fetch all employees
            employees = await Employee.all().values("id", "empid", "name", "email")

        # employees = await Employee.all().values("id","empid", "name", "email")
        
        if not employees:
            raise HTTPException(status_code=404, detail="No employees found")
        
        enriched_employees = []
        for emp in employees:
            emp_id = str(emp["empid"])
            photo_dir = os.path.join(PHOTOS_BASE_PATH, emp_id)
            photo_urls = []
            photo_url = None
            if os.path.isdir(photo_dir):
                files = os.listdir(photo_dir)
                image_files = [f for f in files if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
                for image in  image_files:
                    # Use url_for to generate full URL
                    photo_url = request.url_for("photos", path=f"{emp_id}/{image}")
                    photo_urls.append(photo_url._url)
            # emp["photoUrl"] = photo_url._url if photo_url is not None else None
            emp['photoUrl'] = photo_urls
            enriched_employees.append(emp)

        return {"employees": enriched_employees}
    
    except HTTPException:
        raise  
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")



# create employee
@router.post("/")
async def create_employee(name:str=Form(...), 
                          email:str=Form(...),
                          file:UploadFile=File(...),
                          empid:str=Form(...),
                          is_superadmin: bool=Form(False),
                          is_hr: bool=Form(False),
                          is_manager:bool=Form(False),
                          manager_email: Optional[str] = Form(None),
                          current_user: User = Depends(get_current_user)):
    
    if current_user.is_hr and is_superadmin:
        raise HTTPException(status_code=403, detail="HR cannot create superadmin")

    if not current_user.is_superadmin and not current_user.is_hr:
        raise HTTPException(status_code=403, detail="Only superadmin or HR can create users")

    # if not any([current_user.is_superadmin, current_user.is_hr, current_user.is_manager]):
    #     raise HTTPException(status_code=403, detail="Don't have permission to create employee")
    
    if not name or not email or not file or not empid:
        raise HTTPException(status_code=400, detail="Name, email, file, and id are required")
    exiting_employee = await Employee.get_or_none(empid=empid)
    if exiting_employee:
        raise HTTPException(status_code=400, detail="Employee with this ID already exists")
    exiting_employee = await Employee.get_or_none(email=email)
    if exiting_employee:
        raise HTTPException(status_code=400, detail="Employee with this email already exists")
    
    password = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    hashed_password = pwd_context.hash(password)

    async with in_transaction():
        try:
            employee_obj = await Employee.create(
                name=name, email=email, empid=empid, password=hashed_password
            )

            user = await User.create(
                email=email,
                hashed_password=hashed_password,
                is_superadmin=is_superadmin,
                is_hr=is_hr,
                is_manager=is_manager,
                is_employee=True,
                employee=employee_obj
            )

            if manager_email:
                manager_user = await User.get_or_none(email=manager_email)
                if not manager_user or not manager_user.is_manager:
                    raise HTTPException(status_code=400, detail="Provided manager is invalid or not a manager")

                if manager_user.id == user.id:
                    raise HTTPException(status_code=400, detail="You cannot assign yourself as your own manager")

                if not user.is_employee:
                    raise HTTPException(status_code=400, detail="Only employees can be assigned managers")

                await EmployeeManagerMap.create(employee=employee_obj, manager=manager_user)

            # Save file
            if file.content_type not in ALLOWED_IMAGE_TYPES:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unsupported file type: {file.filename} ({file.content_type})"
                )
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
            os.makedirs(emp_dir, exist_ok=True)
            ext = os.path.splitext(file.filename)[1]
            unique_filename = f"{uuid4().hex}{ext}"
            file_path = os.path.join(emp_dir, unique_filename)
            with open(file_path, "wb") as f:
                f.write(await file.read())
            # await update_embedding(empid)

        except HTTPException:
            raise  # re-raise HTTPExceptions so FastAPI handles them
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
    
    return {"password": password, "empid": empid, "email": email}



#update employee
@router.patch("/update-employee")
async def update_employee(
    empid: str = Form(...),
    name: Optional[str] = Form(None),
    email: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    is_superadmin: Optional[bool] = Form(None),
    is_hr: Optional[bool] = Form(None),
    is_manager: Optional[bool] = Form(None),
    manager_email: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user)
):
    if not current_user.is_superadmin and not current_user.is_hr:
        raise HTTPException(status_code=403, detail="Only superadmin or HR can update employees")
    
    employee_obj = await Employee.get_or_none(empid=empid).prefetch_related("user")
    if not employee_obj:
        raise HTTPException(status_code=404, detail="Employee not found")

    async with in_transaction():

        try:
        # Update employee fields
            if name:
                employee_obj.name = name
            if email:
                # Ensure no other employee has this email
                existing_email = await Employee.get_or_none(email=email)
                if existing_email and existing_email.empid != empid:
                    raise HTTPException(status_code=400, detail="Another employee already uses this email")
                employee_obj.email = email

            await employee_obj.save()

            # Update user fields
            user = await User.get_or_none(employee=employee_obj)
            if not user:
                raise HTTPException(status_code=404, detail="Linked user not found")

            if email:
                # Ensure no other user has this email
                existing_user_with_email = await User.get_or_none(email=email)
                if existing_user_with_email and existing_user_with_email.id != user.id:
                    raise HTTPException(status_code=400, detail="Email is already taken by another user")
                user.email = email
            if is_superadmin is not None:
                user.is_superadmin = is_superadmin
            if is_hr is not None:
                user.is_hr = is_hr
            if is_manager is not None:
                user.is_manager = is_manager

            await user.save()

            # Update manager mapping
            if manager_email:
                manager_user = await User.get_or_none(email=manager_email)
                if not manager_user or not manager_user.is_manager:
                    raise HTTPException(status_code=400, detail="Provided manager is invalid or not a manager")
                
                if manager_user.id == user.id:
                    raise HTTPException(status_code=400, detail="You cannot assign yourself as your own manager")
                
                if not user.is_employee:
                    raise HTTPException(status_code=400, detail="Manger can assigne only those who are employee ")
                # Replace existing mapping or create new
                existing_map = await EmployeeManagerMap.get_or_none(employee=employee_obj)
                if existing_map:
                    existing_map.manager = manager_user
                    await existing_map.save()
                else:
                    await EmployeeManagerMap.create(employee=employee_obj, manager=manager_user)

            # Handle file upload if provided
            if file:
                if file.content_type not in ALLOWED_IMAGE_TYPES:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Unsupported file type: {file.filename} ({file.content_type})"
                    )
                
                os.makedirs(UPLOAD_FOLDER, exist_ok=True)
                emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
                os.makedirs(emp_dir, exist_ok=True)
                ext = os.path.splitext(file.filename)[1]
                unique_filename = f"{uuid4().hex}{ext}"
                file_path = os.path.join(emp_dir, unique_filename)
                with open(file_path, "wb") as f:
                    f.write(await file.read()) 
                
                # await update_embedding(empid)
            

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

    return {"detail": "Employee updated successfully", "empid": empid}


#change-password
@router.post("/change-password")
async def change_password(
    request: Request,
    old_password: str = Form(...),
    new_password: str = Form(...),
    current_user: User= Depends(get_current_user)
):
    async with in_transaction():
        try:
            # Fetch the employee
            user = await User.get_or_none(email=current_user.email)
            if not user:
                raise HTTPException(status_code=404, detail="User not found")

            # Verify old password
            if not pwd_context.verify(old_password, user.hashed_password):
                raise HTTPException(status_code=401, detail="Incorrect old password")

            # Prevent using the same password again
            if pwd_context.verify(new_password, user.hashed_password):
                raise HTTPException(status_code=400, detail="New password must be different from the old password")

            hashed_password = hash_password(new_password)
            if user.is_employee:
                employee = await Employee.get_or_none(email= current_user.email)
                employee.password = hashed_password
                await employee.save()
            # Hash and update the password
            user.hashed_password = hashed_password
            await user.save()

            return {"message": "Password changed successfully"}
        
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


#delete-employee
@router.delete("/delete-employee/{empid}")
async def delete_employee(empid: str, current_user: User = Depends(get_current_user)):
    # Fix: Use 'and' instead of 'or' for permission check
    if not (current_user.is_superadmin or current_user.is_hr):
        raise HTTPException(status_code=403, detail="Only Superadmin or HR can delete an employee")

    try:
        async with in_transaction():
            # Get employee by empid
            employee = await Employee.get_or_none(empid=empid)
            if not employee:
                raise HTTPException(status_code=404, detail="Employee not found")

            # Get associated user
            user = await User.get_or_none(employee=employee)
            if user:
                if user.is_superadmin:
                    raise HTTPException(status_code=403, detail="Cannot delete a Superadmin")
                 
                if user.is_hr and not current_user.is_superadmin:
                    raise HTTPException(status_code=403, detail="Only Superadmin can delete an HR")
                
                if user.id == current_user.id:
                    raise HTTPException(status_code=403, detail="You cannot delete yourself")

                await user.delete()

            await employee.delete()

            emp_dir = os.path.join(UPLOAD_FOLDER, str(employee.empid))
            if os.path.exists(emp_dir):
                shutil.rmtree(emp_dir)
            # await update_embedding(empid)

        return {"message": "Employee and associated user deleted successfully"}

    except HTTPException:
        raise  # pass through expected HTTP errors

    except Exception as e:
        # Optionally log the error here
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


#get photos
@router.get("/photos/{id}")
async def get_employee_photos(id: str, request: Request, current_user: User = Depends(get_current_user)):

    try:

        if not (current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
            raise HTTPException(status_code=403, detail="You don't have permission to get it.")
        
        employee = await Employee.get_or_none(empid=id).values("id","empid", "name", "email")

        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")
        
        employee_obj = await Employee.get(empid=id)
        # Check manager permission
        if current_user.is_manager:
            
            is_managed = await EmployeeManagerMap.filter(
                manager=current_user,
                employee=employee_obj
            ).exists()

            if not is_managed:
                raise HTTPException(status_code=403, detail="You don't have access to this employee's details.")

        emp_id = str(employee["empid"])
        photo_dir = os.path.join(PHOTOS_BASE_PATH, emp_id)

        photo_urls = []
        if os.path.isdir(photo_dir):
            files = os.listdir(photo_dir)
            image_files = [f for f in files if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
            for filename in image_files:
                url = request.url_for("photos", path=f"{emp_id}/{filename}")
                photo_urls.append(url._url)

        return {"urls":photo_urls}
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

#add user photos for model data
@router.post("/addphoto/{id}")
async def add_photo(
    id:str,
    request:Request,
    file:UploadFile=File(...),
    current_user: User = Depends(get_current_user)
    ):
    try:
        if not (current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
                raise HTTPException(status_code=403, detail="You don't have permission to add it.")
        
        employee_obj = await Employee.get_or_none(empid=id)

        if not employee_obj:
            raise HTTPException(status_code=404, detail="Employee not found")

        # Check manager permission
        if current_user.is_manager:
            
            is_managed = await EmployeeManagerMap.filter(
                manager=current_user,
                employee=employee_obj
            ).exists()

            if not is_managed:
                raise HTTPException(status_code=403, detail="You don't have access to this employee's details.")

        emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
        os.makedirs(emp_dir, exist_ok=True)

        if file.content_type not in ALLOWED_IMAGE_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file.filename} ({file.content_type})"
            )   

        ext = os.path.splitext(file.filename)[1]
        unique_filename = f"{uuid4().hex}{ext}"
        file_path = os.path.join(emp_dir, unique_filename)

        with open(file_path, "wb") as f:
            f.write(await file.read())
        # await update_embedding(id)
        # Generate public photo URL
        photo_url = request.url_for("photos", path=f"{employee_obj.empid}/{unique_filename}")._url

        return {"photo_url": photo_url}
    
    except HTTPException:
        raise    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

#delete user photo
@router.post("/deletephoto/{id}")
async def delete_photo(id: str,
                    file: str = Form(...),
                    current_user: User = Depends(get_current_user)):
    try:
        if not (current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
                raise HTTPException(status_code=403, detail="You don't have permission to delete it.")
     
        employee_obj = await Employee.get_or_none(empid=id)
        if not employee_obj:
            raise HTTPException(status_code=404, detail="Employee not found")

        # Check manager permission
        if current_user.is_manager:
            
            is_managed = await EmployeeManagerMap.filter(
                manager=current_user,
                employee=employee_obj
            ).exists()

            if not is_managed:
                raise HTTPException(status_code=403, detail="You don't have access to this employee's details.")

        emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
        file_path = os.path.join(emp_dir, file)

        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="File not found")
        image_files = [
            f for f in os.listdir(emp_dir)
            if os.path.isfile(os.path.join(emp_dir, f))
            and f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
        ]
        if len(image_files) <= 1:   
            raise HTTPException(
                status_code=400,
                detail="At least one photo must remain."
            )
        os.remove(file_path)
        # await update_embedding(id)
        return {"message": "Photo deleted successfully"}
    
    except HTTPException:
        raise    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


#get manager list
@router.get("/managers/", response_model= list[UserOut])
async def get_managers(request: Request, current_user: User= Depends(get_current_user)):
    try:
        if not (current_user.is_superadmin or current_user.is_hr):
            raise HTTPException(status_code= 403, 
                                detail="Don't have permission to get the managers list")
        
        managers= await User.filter(is_manager=True).prefetch_related("employee", "employees_managed__employee").all()
        return managers
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# get all employee under manager
@router.get("/manager_employee/{id}", response_model= List[EmployeeOut])
async def get_manager_employees(id= str, current_user: User= Depends(get_current_user)):
    try:
        if not (current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
            raise HTTPException(status_code= 403, 
                                detail="Don;t have permission to get the managers list")
        
        manager_user = await User.get_or_none(employee__empid = id , is_manager=True )
        if not manager_user:
            raise HTTPException(status_code=404, detail="Manager not found")
        # mappings = await EmployeeManagerMap.filter(manager=manager_user).prefetch_related("employee")
        # employees = [m.employee for m in mappings]
        employees = await Employee.filter(manager_mapping__manager=manager_user).all()
        return employees

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


# #logout
# @router.post("/logout")
# async def logout():
#     return {"message": "Logout successful"}


# async def process_latest_entry(empid: str):
#     await asyncio.sleep(60)  # wait for debounce duration
#     latest = entry_buffer.pop(empid, None)

#     if latest:
#         try:
#             employee = await Employee.get(empid=empid)
#         except DoesNotExist:
#             print(f"Employee {empid} not found during processing.")
#             return

#         current_time = datetime.now(LOCAL_TIMEZONE)
#         await TimeLog.create(employee=employee, action="IN", timestamp=current_time)
#         print(f"{empid} Entered at {current_time}!", flush=True)


# @router.post("/enter")
# async def enter(request: Request):
#     data = await request.json()
#     empid = data.get("empid")

#     if not empid:
#         return JSONResponse(status_code=400, content={"error": "empid is required"})

#     try:
#         await Employee.get(empid=empid)
#     except DoesNotExist:
#         return JSONResponse(status_code=404, content={"error": "Employee not found"})

#     now = time.time()

#     if empid in entry_buffer:
#         # Update the existing buffer with latest data
#         entry_buffer[empid]["data"] = data
#         entry_buffer[empid]["timestamp"] = now
#         # No need to cancel the task; it will run after delay
#     else:
#         # New entry: schedule processing
#         task = asyncio.create_task(process_latest_entry(empid))
#         entry_buffer[empid] = {
#             "data": data,
#             "timestamp": now,
#             "task": task
#         }
#     employee = await Employee.get_or_none(empid=empid)
#     for ws in connected_clients:
#         try:
#             await ws.send_json({"type": "entry", "name":employee.name})
#         except Exception as e:
#             connected_clients.remove(ws)
#     print(empid," entered")
#     return {"status": "received", "message": f"Latest entry for employee {empid} will be processed after 60 seconds"}

# exit_buffer = {}

# async def process_latest_exit(empid: str):
#     await asyncio.sleep(60)
#     latest = exit_buffer.pop(empid, None)

#     if latest:
#         try:
#             employee = await Employee.get(empid=empid)
#         except DoesNotExist:
#             print(f"Employee {empid} not found during EXIT processing.")
#             return

#         current_time = datetime.now(LOCAL_TIMEZONE)
#         await TimeLog.create(employee=employee, action="OUT", timestamp=current_time)
#         print(f"{empid} Exited at {current_time}!", flush=True)


# @router.post("/exit")
# async def exit(request: Request):
#     data = await request.json()
#     empid = data.get("empid")

#     if not empid:
#         return JSONResponse(status_code=400, content={"error": "empid is required"})

#     try:
#         await Employee.get(empid=empid)
#     except DoesNotExist:
#         return JSONResponse(status_code=404, content={"error": "Employee not found"})

#     now = time.time()

#     if empid in exit_buffer:
#         # Update with latest data
#         exit_buffer[empid]["data"] = data
#         exit_buffer[empid]["timestamp"] = now
#     else:
#         # Create new scheduled task
#         task = asyncio.create_task(process_latest_exit(empid))
#         exit_buffer[empid] = {
#             "data": data,
#             "timestamp": now,
#             "task": task
#         }
#     employee = await Employee.get_or_none(empid=empid)
#     for ws in connected_clients:
#         try:
#             await ws.send_json({"type": "exit", "name":employee.name})
#         except Exception as e:
#             connected_clients.remove(ws)
#     print(empid," exited")
#     return {"status": "received", "message": f"Latest exit for employee {empid} will be processed after 60 seconds"}

# @router.get("/attendance/{empid}")
# async def get_attendance_summary(
#     empid: str,
#     start_date: date = Query(...),
#     end_date: date = Query(...)
# ):
#     employee = await Employee.get_or_none(empid=empid)
#     if not employee:
#         return {"error": "Employee not found"}

#     result = []
#     today = date.today()

#     current = start_date
#     while current <= end_date:
#         next_day = current + timedelta(days=1)
#         logs = await TimeLog.filter(
#             employee=employee,
#             timestamp__gte=datetime.combine(current, datetime.min.time()),
#             timestamp__lt=datetime.combine(next_day, datetime.min.time())
#         ).order_by("timestamp")

#         entry_time = None
#         exit_time = None
#         in_time = 0
#         corrupted = False
#         inside = False
#         last_in = None
#         in_out_pairs = []

#         for log in logs:
#             if log.action == "IN":
#                 if inside:
#                     corrupted = True  # Two consecutive INs
#                 else:
#                     last_in = log.timestamp
#                     inside = True
#                     if not entry_time:
#                         entry_time = log.timestamp
#             elif log.action == "OUT":
#                 if inside and last_in:
#                     delta = (log.timestamp - last_in).total_seconds()
#                     in_time += delta
#                     in_out_pairs.append((last_in, log.timestamp))
#                     exit_time = log.timestamp
#                     inside = False
#                     last_in = None
#                 else:
#                     corrupted = True  # OUT without prior IN

#         # Handle unmatched IN (still inside)
#         if inside:
#             if current == today:
#                 corrupted = False  # Allow it for today
#                 exit_time = None  # Don't set lastExit if still inside
#             else:
#                 corrupted = True

#         total_span = 0
#         total_out_time = 0
#         if entry_time and exit_time and entry_time < exit_time:
#             total_span = (exit_time - entry_time).total_seconds()
#             total_out_time = total_span - in_time
#          # Python 3.9+
# # Or use `pytz` if you're on Python < 3.9

        
#         result.append({
#             "date": current.strftime("%Y-%m-%d"),
#             "firstEntry": convert_to_local(entry_time).strftime("%I:%M %p") if entry_time else "-",
#             "lastExit": convert_to_local(exit_time).strftime("%I:%M %p") if exit_time else "-",  # will be "-" if still inside today
#             "totalInTime": format_duration(int(in_time)) if entry_time and exit_time else "-",
#             "totalOutTime": format_duration(int(total_out_time)) if entry_time and exit_time else "-",
#             "status": "Present" if entry_time and not corrupted else ("Absent" if not entry_time else "Corrupted")
#         })

#         current += timedelta(days=1)

#     return result

# @router.get("/summary/{target_date}")
# async def get_attendance_summary_by_date(target_date: str):
#     try:
#         target_date = datetime.strptime(target_date, "%Y-%m-%d").date()
#     except ValueError:
#         raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD.")

#     all_employees = await Employee.all()
#     total_employees = len(all_employees)

#     present = []
#     absent = []

#     today = date.today()

#     for employee in all_employees:
#         start_dt = datetime.combine(target_date, datetime.min.time())
#         end_dt = datetime.combine(target_date + timedelta(days=1), datetime.min.time())

#         logs = await TimeLog.filter(
#             employee=employee,
#             timestamp__gte=start_dt,
#             timestamp__lt=end_dt
#         ).order_by("timestamp")

#         entry_time = None
#         exit_time = None
#         in_time = 0
#         corrupted = False
#         inside = False
#         last_in = None
#         in_out_pairs = []

#         for log in logs:
#             if log.action == "IN":
#                 if inside:
#                     corrupted = True
#                 else:
#                     last_in = log.timestamp
#                     inside = True
#                     if not entry_time:
#                         entry_time = log.timestamp
#             elif log.action == "OUT":
#                 if inside and last_in:
#                     delta = (log.timestamp - last_in).total_seconds()
#                     in_time += delta
#                     in_out_pairs.append((last_in, log.timestamp))
#                     exit_time = log.timestamp
#                     inside = False
#                     last_in = None
#                 else:
#                     corrupted = True

#         if inside:
#             if target_date == today:
#                 corrupted = False
#                 exit_time = None
#             else:
#                 corrupted = True

#         total_span = 0
#         total_out_time = 0
#         if entry_time and exit_time and entry_time < exit_time:
#             total_span = (exit_time - entry_time).total_seconds()
#             total_out_time = total_span - in_time

#         attendance_info = {
#             "empid": employee.empid,
#             "name": employee.name,
#             "firstEntry": convert_to_local(entry_time).strftime("%I:%M %p") if entry_time else "-",
#             "lastExit": convert_to_local(exit_time).strftime("%I:%M %p") if exit_time else "-",
#             "totalInTime": format_duration(int(in_time)) if entry_time and exit_time else "-",
#             "totalOutTime": format_duration(int(total_out_time)) if entry_time and exit_time else "-",
#             "status": "Present" if entry_time and not corrupted else ("Absent" if not entry_time else "Corrupted")
#         }

#         if attendance_info["status"] == "Present":
#             present.append(attendance_info)
#         elif attendance_info["status"] == "Absent":
#             absent.append(attendance_info)
#         else:
#             present.append(attendance_info)  # You can separate corrupted if needed

#     return {
#         "date": target_date.strftime("%Y-%m-%d"),
#         "totalEmployees": total_employees,
#         "totalPresent": len(present),
#         "totalAbsent": len(absent),
#         "presentEmployees": present,
#         "absentEmployees": absent
#     }













# @router.post("/create-employee")
# async def create_employee(data: EmployeeCreate):
#     # Step 1: Check if user already exists
#     existing = await User.get_or_none(username=data.username)
#     if existing:
#         raise HTTPException(status_code=400, detail="Username already exists")

#     # Step 2: Create user with role 'employee'
#     user = await User.create(
#         username=data.username,
#         email=data.email,
#         password=hash_password(data.password),
#         role="employee"
#     )

#     # Step 3: Create employee profile linked to user
#     employee = await Employee.create(
#         user=user,
#         empid=data.empid,
#         employee_name=data.employee_name
#     )

#     return {
#         "user_id": user.id,
#         "employee_id": employee.id,
#         "username": user.username,
#         "employee_name": employee.employee_name
#     }


# @router.post("/")
# async def create_employee(name:str=Form(...), email:str=Form(...),file:UploadFile=File(...),empid:str=Form(...)):
#     if not name or not email or not file or not empid:
#         raise HTTPException(status_code=400, detail="Name, email, file, and id are required")
#     exiting_employee = await Employee.get_or_none(empid=empid)
#     if exiting_employee:
#         raise HTTPException(status_code=400, detail="Employee with this ID already exists")
#     # exiting_employee = await Employee.get_or_none(email=email)
#     # if exiting_employee:
#     #     raise HTTPException(status_code=400, detail="Employee with this email already exists")
    
#     password = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
#     hashed_password = hash_password(password)
#     employee_obj = await Employee.create(name=name, email=email,empid=empid,password=hashed_password)
#     if not employee_obj:
#         raise HTTPException(status_code=400, detail="Employee creation failed")
#     emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
#     os.makedirs(emp_dir, exist_ok=True)
#     if file.content_type not in ALLOWED_IMAGE_TYPES:
#         raise HTTPException(
#             status_code=400,
#             detail=f"Unsupported file type: {file.filename} ({file.content_type})"
#         )   
#     ext = os.path.splitext(file.filename)[1]
#     unique_filename = f"{uuid4().hex}{ext}"
#     file_path = os.path.join(emp_dir, unique_filename)
#     with open(file_path, "wb") as f:
#         f.write(await file.read())
#     # await update_embedding(empid)
#     return {"password":password,"empid":empid,"email":email}



# @router.delete("/{id}")
# async def delete_employee(id:str,username = Depends(authenticate_user)):
    
#     employee_obj = await Employee.get_or_none(empid=id)
#     if not employee_obj:
#         raise HTTPException(status_code=404, detail="Employee not found")
#     await employee_obj.delete()
#     emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
#     if os.path.exists(emp_dir):
#         shutil.rmtree(emp_dir)
#     await update_embedding(id)
#     return {"deleted"}


# @router.put("/{id}")
# async def update_employee(
#     id: str,
#     empid: str = Form(...),
#     name: str = Form(...),
#     email: str = Form(...),
#     password: Optional[str] = Form(None),  # ✅ Make password optional
#     username = Depends(authenticate_user)
# ):
#     employee_obj = await Employee.get_or_none(empid=id)
#     if not employee_obj:
#         raise HTTPException(status_code=404, detail="Employee not found")

#     existing_employee = await Employee.get_or_none(email=email)
#     if existing_employee and existing_employee.empid != id:
#         raise HTTPException(status_code=400, detail="Employee with this email already exists")

#     existing_employee = await Employee.get_or_none(empid=empid)
#     if existing_employee and existing_employee.empid != id:
#         raise HTTPException(status_code=400, detail="Employee with this ID already exists")

#     # Rename photo directory if empid changed
#     old_empid = employee_obj.empid
#     if empid != old_empid:
#         old_dir = os.path.join(UPLOAD_FOLDER, str(old_empid))
#         new_dir = os.path.join(UPLOAD_FOLDER, str(empid))
#         if os.path.exists(old_dir):
#             os.rename(old_dir, new_dir)
#         await update_embedding(empid)
#         await update_embedding(old_empid)

#     # Update fields
#     employee_obj.name = name
#     employee_obj.email = email
#     employee_obj.empid = empid

#     # ✅ Update password only if not empty/None
#     if password:
#         employee_obj.password = pwd_context.hash(password)

#     await employee_obj.save()
    
#     return {"emp": {"empid": employee_obj.empid, "name": employee_obj.name, "email": employee_obj.email}}





# @router.post("/addphoto/{id}")
# async def add_photo(id:str,request:Request, file:UploadFile=File(...), current_user: User = Depends(get_current_user)):
#     try:
#         if not (current_user.is_superadmin or current_user.is_hr or current_user.is_manager):
#                 raise HTTPException(status_code=403, detail="You don't have permission to get it.")
        
#         employee_obj = await Employee.get_or_none(empid=id)
#         if not employee_obj:
#             raise HTTPException(status_code=404, detail="Employee not found")

#         emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
#         os.makedirs(emp_dir, exist_ok=True)

#         if file.content_type not in ALLOWED_IMAGE_TYPES:
#             raise HTTPException(
#                 status_code=400,
#                 detail=f"Unsupported file type: {file.filename} ({file.content_type})"
#             )   

#         ext = os.path.splitext(file.filename)[1]
#         unique_filename = f"{uuid4().hex}{ext}"
#         file_path = os.path.join(emp_dir, unique_filename)

#         with open(file_path, "wb") as f:
#             f.write(await file.read())
#         await update_embedding(id)
#         # Generate public photo URL
#         photo_url = request.url_for("photos", path=f"{employee_obj.empid}/{unique_filename}")._url

#         return {"photo_url": photo_url}
    
#     except HTTPException:
#         raise    
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


# @router.post("/deletephoto/{id}")
# async def delete_photo(id: str,file: str = Form(...),username = Depends(authenticate_user)):
#     employee_obj = await Employee.get_or_none(empid=id)
#     if not employee_obj:
#         raise HTTPException(status_code=404, detail="Employee not found")

#     emp_dir = os.path.join(UPLOAD_FOLDER, str(employee_obj.empid))
#     file_path = os.path.join(emp_dir, file)

#     if not os.path.exists(file_path):
#         raise HTTPException(status_code=404, detail="File not found")
#     image_files = [
#         f for f in os.listdir(emp_dir)
#         if os.path.isfile(os.path.join(emp_dir, f))
#            and f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
#     ]
#     if len(image_files) <= 1:   
#         raise HTTPException(
#             status_code=400,
#             detail="At least one photo must remain."
#         )
#     os.remove(file_path)
#     await update_embedding(id)
#     return {"message": "Photo deleted successfully"}




# @router.post("/login")
# async def login(response:Response,empid:str=Form(...),password:str=Form(...)):
#     employee = await Employee.get_or_none(
#         Q(empid=empid)
#     )
#     # if not employee or not verify_password(password, employee.user.password):
#     #     raise HTTPException(status_code=401, detail="Invalid credentials")
#     token = create_token({"empid": employee.empid})
#     response.set_cookie(
#         key="access_token",
#         value=token,
#         httponly=True,
#         secure=True, 
#         samesite="none",
           
#     )
#     return {"access_token": token, "token_type": "bearer","empid": employee.empid,"name":employee.employee_name}


# @router.post("/logout")
# async def logout(response: Response):
#     response.delete_cookie("access_token")
#     return {"message": "Logout successful"}