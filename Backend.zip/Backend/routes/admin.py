from fastapi import APIRouter, Depends, HTTPException
from User.models import User
from RBAD import superuser_required
from utils import hash_password
from pydantic import BaseModel,EmailStr

router = APIRouter(
    prefix="/admin",
    tags=["Admin/HR"]
)

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    role: str 

class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr
    role: str

    class Config:
        orm_mode = True

@router.post("/create-admin", response_model=UserOut)
async def create_admin(data: UserCreate, user=Depends(superuser_required)):
    if data.role not in ["admin", "HR", "employee"]:
        raise HTTPException(status_code=400, detail="Only admin or HR roles allowed")

    existing = await User.get_or_none(username=data.username)
    if existing:
        raise HTTPException(status_code=400, detail="User already exists")

    new_user = await User.create(
        username=data.username,
        email=data.email,
        password=hash_password(data.password),
        role=data.role
    )
    return new_user

