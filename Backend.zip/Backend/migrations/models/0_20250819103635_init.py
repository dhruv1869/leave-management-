from tortoise import BaseDBAsyncClient


async def upgrade(db: BaseDBAsyncClient) -> str:
    return """
        CREATE TABLE IF NOT EXISTS `admin` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(100) NOT NULL,
    KEY `idx_admin_usernam_6c25e3` (`username`)
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `employee` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `empid` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(100) NOT NULL,
    `name` VARCHAR(50) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `environment` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `key` VARCHAR(50) NOT NULL UNIQUE,
    `value` VARCHAR(100) NOT NULL
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `missreport` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `timestamp` DATETIME(6) NOT NULL,
    `action` VARCHAR(10) NOT NULL,
    `reason` VARCHAR(300) NOT NULL,
    `status` VARCHAR(10) NOT NULL,
    `employee_id` INT NOT NULL,
    CONSTRAINT `fk_missrepo_employee_d908d60c` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `timelog` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `timestamp` DATETIME(6) NOT NULL,
    `action` VARCHAR(10) NOT NULL,
    `employee_id` INT NOT NULL,
    CONSTRAINT `fk_timelog_employee_e2803888` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `aerich` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `version` VARCHAR(255) NOT NULL,
    `app` VARCHAR(100) NOT NULL,
    `content` JSON NOT NULL
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `user` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `hashed_password` VARCHAR(255) NOT NULL,
    `is_superadmin` BOOL NOT NULL DEFAULT 0,
    `is_hr` BOOL NOT NULL DEFAULT 0,
    `is_manager` BOOL NOT NULL DEFAULT 0,
    `is_employee` BOOL NOT NULL DEFAULT 1,
    `created_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    `updated_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    `employee_id` INT,
    CONSTRAINT `fk_user_employee_882eaffe` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE SET NULL
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `leavebalance` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `sick_leave` DOUBLE NOT NULL DEFAULT 0,
    `casual_leave` DOUBLE NOT NULL DEFAULT 0,
    `optional_leave` DOUBLE NOT NULL DEFAULT 0,
    `earned_leave` DOUBLE NOT NULL DEFAULT 0,
    `total_sick_leave` DOUBLE NOT NULL DEFAULT 0,
    `total_casual_leave` DOUBLE NOT NULL DEFAULT 0,
    `total_optional_leave` DOUBLE NOT NULL DEFAULT 0,
    `total_earned_leave` DOUBLE NOT NULL DEFAULT 0,
    `created_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    `updated_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    `employee_id` INT NOT NULL,
    `updated_by_id` INT,
    CONSTRAINT `fk_leavebal_employee_866fc327` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_leavebal_user_c79715a3` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `leaverequest` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `leave_type` VARCHAR(20) NOT NULL,
    `apply_date` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL,
    `total_days` DECIMAL(4,1) NOT NULL DEFAULT 0,
    `leave_without_pay` DECIMAL(4,1) NOT NULL DEFAULT 0,
    `reason` LONGTEXT,
    `attachment` VARCHAR(255),
    `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
    `half_day_start_type` VARCHAR(20),
    `half_day_end_type` VARCHAR(10),
    `approve_date` DATE,
    `approve_comment` LONGTEXT,
    `reject_date` DATE,
    `reject_comment` LONGTEXT,
    `casual_deducted` DECIMAL(4,1) NOT NULL DEFAULT 0,
    `earned_deducted` DECIMAL(4,1) NOT NULL DEFAULT 0,
    `sick_deducted` DECIMAL(4,1) NOT NULL DEFAULT 0,
    `optional_deducted` DECIMAL(4,1) NOT NULL DEFAULT 0,
    `created_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    `updated_at` DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    `action_by_id` INT,
    `employee_id` INT NOT NULL,
    CONSTRAINT `fk_leavereq_user_c83b450f` FOREIGN KEY (`action_by_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_leavereq_employee_9368a341` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;
CREATE TABLE IF NOT EXISTS `employeemanagermap` (
    `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `employee_id` INT NOT NULL,
    `manager_id` INT NOT NULL,
    CONSTRAINT `fk_employee_employee_55f348bb` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_employee_user_86db9ab6` FOREIGN KEY (`manager_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) CHARACTER SET utf8mb4;"""


async def downgrade(db: BaseDBAsyncClient) -> str:
    return """
        """
