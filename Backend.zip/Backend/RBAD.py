from fastapi import Depends, HTTPException, status
from auth import get_current_user  # JWT-based user retrieval

def superuser_required(user=Depends(get_current_user)):
    if user.role != "superuser":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only superusers can access this resource"
        )
    return user
